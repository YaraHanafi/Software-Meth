package lib.App;

import javafx.application.Application;
import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;
import lib.model.Admin;

import java.io.IOException;

/**
 * @author Akhil Mohammed
 * @author Yara Hanafi
 *
 */

public class Photos extends Application {

    public static Admin adminMain = new Admin();
    public static Stage mainStage;

    @Override
    public void start(Stage primaryStage)
            throws IOException {

        mainStage = primaryStage;

        FXMLLoader loader = new FXMLLoader();
        loader.setLocation(getClass().getResource("/lib/view/Login.fxml"));
        VBox root = (VBox) loader.load();

        Scene scene = new Scene(root);
        primaryStage.setScene(scene);
        primaryStage.setTitle("Login Screen");
        primaryStage.setResizable(true);
        primaryStage.show();

        mainStage.setOnCloseRequest(x -> {
            try {
                Admin.Save(adminMain);
            } catch (IOException e) {
                e.printStackTrace();
            }
        });
    }

    public static void main(String[] args) throws IOException, ClassNotFoundException {
        try {
            adminMain = Admin.Load();
        }catch (IOException e) {
            e.printStackTrace();
        }
        launch(args);
    }

}
