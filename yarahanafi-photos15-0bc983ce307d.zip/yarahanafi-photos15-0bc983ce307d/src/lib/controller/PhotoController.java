package lib.controller;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.VBox;
import javafx.stage.FileChooser;
import javafx.stage.Stage;
import lib.App.Photos;
import lib.model.*;

import java.io.*;
import java.util.ArrayList;
import java.util.Optional;

/**
 * @author Akhil Mohammed
 * @author Yara Hanafi
 *
 */

public class PhotoController {

    @FXML Button Quit_button;
    @FXML Button AddTag_button;
    @FXML Button AddPhoto_button;
    @FXML Button AddCaption_button;
    @FXML Button DeletePhoto_button;
    @FXML Button Logout_button;
    @FXML Button SlideShow_button;
    @FXML Button RemoveTag_button;
    @FXML Button MovePhoto_button;
    @FXML Button CopyPhoto_button;

    @FXML ImageView Imagev;

    @FXML Label Caption;
    @FXML Label Date;

    @FXML ListView<Photo> Photo_list;
    @FXML ListView<Tag> Tag_list;

    @FXML TextField Caption_New;
    @FXML TextField Album_MoveCopy;
    @FXML TextField Tag_Type;
    @FXML TextField Tag_Value;

    public static Album MyAlbum;
    public static User MyUser;
    private ArrayList<Photo> PhotosList = new ArrayList<Photo>();
    private ArrayList<Tag> TagList = new ArrayList<Tag>();
    private ObservableList<Photo> obsPhotosList;
    private ObservableList<Tag> obsTagList;
    public static Admin admin = Photos.adminMain;

    public void start() throws FileNotFoundException {
        Imagev.setImage(null);
        updatelist();
        Photo_list.getSelectionModel().select(0);
        details();
        //listener
        Photo_list.getSelectionModel().selectedIndexProperty().addListener(
                (obs,oldVal, newVal) ->
                        details());
    }

    public void details(){
        Photo CurrPhoto = Photo_list.getSelectionModel().getSelectedItem();
        if (CurrPhoto != null) {
            Imagev.setImage(new Image(CurrPhoto.getPic().toURI().toString()));
            Caption.setText(CurrPhoto.getCaption());
            Date.setText(CurrPhoto.getDateString());
            TagList.clear();
            for(int i=0; i<CurrPhoto.getTags().size(); i++){
                TagList.add(CurrPhoto.getTags().get(i));
            }
            obsTagList = FXCollections.observableArrayList(TagList);
            Tag_list.setItems(obsTagList);
        } else{
            Imagev.setImage(null);
            Caption.setText("");
            Date.setText("");
            TagList.clear();
            obsTagList = FXCollections.observableArrayList(TagList);
            Tag_list.setItems(obsTagList);
        }
    }

    public void updatelist() {
        PhotosList.clear();

        for(int i=0; i<MyAlbum.getPhotos().size(); i++){
            PhotosList.add(MyAlbum.getPhotos().get(i));
        }

        obsPhotosList = FXCollections.observableArrayList(PhotosList);
        Photo_list.setItems(obsPhotosList);

        Photo_list.setCellFactory(param -> new ListCell<Photo>() {
            private ImageView imageView = new ImageView();
            @Override
            public void updateItem(Photo photo, boolean empty) {
                super.updateItem(photo, empty);
                if (empty) {
                    setText(null);
                    setGraphic(null);
                } else {
                    Image image = new Image(photo.getPic().toURI().toString());
                    imageView.setImage(image);
                    imageView.setFitHeight(50);
                    imageView.setFitWidth(50);
                    setText(photo.getCaption());
                    setGraphic(imageView);

                }
            }
        });

    }

    public void Quit(ActionEvent e){
        try {
            Admin.Save(admin);
        } catch (IOException a) {
            a.printStackTrace();
        }
        Stage stage = (Stage) Quit_button.getScene().getWindow();
        stage.close();
    }

    public void Logout(ActionEvent e) throws IOException {
        Alert alert = new Alert(Alert.AlertType.CONFIRMATION);
        alert.setTitle("Logout Confirmation");
        alert.setHeaderText("Confirm");
        alert.setContentText("Are you sure you want to logout?");

        Optional<ButtonType> result = alert.showAndWait();
        if (result.get() == ButtonType.OK) {
            Admin.Save(admin);
            FXMLLoader loader = new FXMLLoader();
            loader.setLocation(getClass().getResource("/lib/view/Login.fxml"));
            VBox root = (VBox) loader.load();

            Scene scene = new Scene(root);
            Photos.mainStage.setScene(scene);
            Photos.mainStage.setTitle("Login Screen");
            Photos.mainStage.setResizable(true);
            Photos.mainStage.show();
        } else {
            return;
        }
    }

    public void AddTag (ActionEvent e) throws IOException {
        Alert alert = new Alert(Alert.AlertType.ERROR);
        if(Photo_list.getSelectionModel().getSelectedIndex() == -1){
            alert.setTitle("Add Tag Error Message");
            alert.setHeaderText("Error");
            alert.setContentText("Please Select Photo to Add Tag");
            alert.showAndWait();
            return;
        }

        String type = Tag_Type.getText().trim();
        String value = Tag_Value.getText().trim();


        if((type.isEmpty() && value.isEmpty()) || (type==null && value == null)) {
            alert.setTitle("Add Tag Error Message");
            alert.setHeaderText("Error");
            alert.setContentText("Please Enter a Type and Value to add tag");
            alert.showAndWait();
            return;
        } else if(type.isEmpty()|| type==null) {
            alert.setTitle("Add Tag Error Message");
            alert.setHeaderText("Error");
            alert.setContentText("Please Enter a Type to add tag");
            alert.showAndWait();
            return;
        }else if(value.isEmpty()|| value==null) {

            for(int i=0; i< MyUser.preList.size(); i++){
                if(MyUser.preList.get(i).getType().equals(type)){
                    alert.setTitle("Add Tag Type Error Message");
                    alert.setHeaderText("Error");
                    alert.setContentText("This Tag Type already exists in prelist of Tag Types");
                    alert.showAndWait();
                    return;
                }
            }

            Alert alert1 = new Alert(Alert.AlertType.CONFIRMATION);
            alert1.setTitle("Add Type Confirmation");
            alert1.setHeaderText("Confirm");
            alert1.setContentText("This Tag will be added to current photo. Do you want to add this Tag Type to prelist of Tag Types?");

            Optional<ButtonType> result1 = alert1.showAndWait();
            if (result1.get() == ButtonType.OK) {
                MyUser.preList.add(new Tag(type, " "));
                for(int i=0; i<MyUser.getAlbums().size(); i++){
                    Album albumCurr = MyUser.getAlbums().get(i);
                    for(int j=0; j<albumCurr.getPhotos().size(); j++){
                        albumCurr.getPhotos().get(j).SetNewTagType(type);
                    }
                }

            } else {
                int Index = Photo_list.getSelectionModel().getSelectedIndex();
                Photo photoCurr = MyAlbum.getPhotos().get(Index);
                for(int i=0; i<MyUser.getAlbums().size(); i++){
                    Album albumCurr = MyUser.getAlbums().get(i);
                    if(albumCurr.checkPhotoExist(photoCurr.getFilePath())){
                        albumCurr.getCurrentPhoto().getTags().add(new Tag(type," "));
                    }
                }
            }
            updatelist();
            details();
        } else{
            int Index = Photo_list.getSelectionModel().getSelectedIndex();
            Photo photoCurr = MyAlbum.getPhotos().get(Index);
            if(photoCurr.checkTagExist(type,value)){
                alert.setTitle("Add Tag Error Message");
                alert.setHeaderText("Error");
                alert.setContentText("This Tag already exists in list. Try adding a New Tag");
                alert.showAndWait();
                return;
            }
            if(type.equals("location")){
                for(int i=0; i<photoCurr.getTags().size(); i++){
                    if(photoCurr.getTags().get(i).getType().equals(type) && (!photoCurr.getTags().get(i).getValue().equals(" "))){
                        alert.setTitle("Add Tag Error Message");
                        alert.setHeaderText("Error");
                        alert.setContentText("A location tag already exists. There can only be one location tag");
                        alert.showAndWait();
                        return;
                    }
                }
            }
            for(int i=0; i<MyUser.getAlbums().size(); i++){
                Album albumCurr = MyUser.getAlbums().get(i);
                if(albumCurr.checkPhotoExist(photoCurr.getFilePath())){
                    for(int l=0; l<albumCurr.getCurrentPhoto().getTags().size(); l++){
                        if(albumCurr.getCurrentPhoto().getTags().get(l).getType().equals(type) && albumCurr.getCurrentPhoto().getTags().get(l).getValue().equals(" ")){
                            albumCurr.getCurrentPhoto().removeTag(type," ");
                        }
                    }
                    albumCurr.getCurrentPhoto().getTags().add(new Tag(type,value));
                }
            }
            updatelist();
            details();
        }
        Admin.Save(admin);
    }

    public void AddPhoto (ActionEvent e) throws IOException {
        FileChooser filechooser = new FileChooser();
        FileChooser.ExtensionFilter Filter = new FileChooser.ExtensionFilter("Image Files", "*.png", "*.jpg", "*.jpeg", "*.gif", "*.bmp");
        filechooser.getExtensionFilters().add(Filter);
        File image = filechooser.showOpenDialog(null);

        if (image == null) {
            return;
        } else if (MyAlbum.checkPhotoExist(image.getAbsolutePath())) {
			Alert alert = new Alert(Alert.AlertType.ERROR);
			alert.setTitle("Add Photo Error");
            alert.setHeaderText("Error");
			alert.setContentText("Photo already exists in album. Select another Photo");
			alert.showAndWait();
			return;
		}else {
            String path = image.getAbsolutePath();
            Photo addphoto;
            if(MyUser.getName().equals("stock")) {
                int index;
                if (path.contains("StockPhotos")) {
                    index = path.indexOf("StockPhotos");
                    String newpath = path.substring(index);
                    if(MyAlbum.checkPhotoExist(newpath)){
                        Alert alert = new Alert(Alert.AlertType.ERROR);
                        alert.setTitle("Add Photo Error");
                        alert.setHeaderText("Error");
                        alert.setContentText("Photo already exists in album. Select another Photo");
                        alert.showAndWait();
                        return;
                    }
                    addphoto = new Photo(image, newpath,true);
                    for(int j=0; j<MyUser.preList.size(); j++){
                        addphoto.addTag(MyUser.preList.get(j).getType(),MyUser.preList.get(j).getValue());
                    }
                    for(int i=0; i<MyUser.getAlbums().size(); i++){
                        Album albumCurr = MyUser.getAlbums().get(i);
                        if(albumCurr.checkPhotoExist(addphoto.getFilePath())){
                            addphoto.renameCaption(albumCurr.getCurrentPhoto().getCaption());
                            addphoto.setTags(albumCurr.getCurrentPhoto().getTags());
                            addphoto.setDate(albumCurr.getCurrentPhoto().getDate());
                        }
                    }
                    MyAlbum.addPhoto(addphoto);
                } else {
                    addphoto = new Photo(image, path, false);
                    for(int j=0; j<MyUser.preList.size(); j++){
                        addphoto.addTag(MyUser.preList.get(j).getType(),MyUser.preList.get(j).getValue());
                    }
                    for(int i=0; i<MyUser.getAlbums().size(); i++){
                        Album albumCurr = MyUser.getAlbums().get(i);
                        if(albumCurr.checkPhotoExist(addphoto.getFilePath())){
                            addphoto.renameCaption(albumCurr.getCurrentPhoto().getCaption());
                            addphoto.setTags(albumCurr.getCurrentPhoto().getTags());
                            addphoto.setDate(albumCurr.getCurrentPhoto().getDate());
                        }
                    }
                    MyAlbum.addPhoto(addphoto);
                }
            } else {
                addphoto = new Photo(image, path, false);
                for(int j=0; j<MyUser.preList.size(); j++){
                    addphoto.addTag(MyUser.preList.get(j).getType(),MyUser.preList.get(j).getValue());
                }
                for(int i=0; i<MyUser.getAlbums().size(); i++){
                    Album albumCurr = MyUser.getAlbums().get(i);
                    if(albumCurr.checkPhotoExist(addphoto.getFilePath())){
                        addphoto.renameCaption(albumCurr.getCurrentPhoto().getCaption());
                        addphoto.setTags(albumCurr.getCurrentPhoto().getTags());
                        addphoto.setDate(albumCurr.getCurrentPhoto().getDate());
                    }
                }
                MyAlbum.addPhoto(addphoto);
            }
            updatelist();
            Admin.Save(admin);
        }

    }

    public void AddCaption (ActionEvent e){
        Alert alert = new Alert(Alert.AlertType.ERROR);
        if(Photo_list.getSelectionModel().getSelectedIndex() == -1){
            alert.setTitle("Caption Photo Error Message");
            alert.setHeaderText("Error");
            alert.setContentText("Please Select Photo to Caption");
            alert.showAndWait();
            return;
        }

        String caption = Caption_New.getText().trim();
        if(caption.isEmpty() || caption == null) {
            alert.setTitle("Caption Photo Error Message");
            alert.setHeaderText("Error");
            alert.setContentText("Please Enter a Caption Name");
            alert.showAndWait();
            return;
        } else{
            int Index = Photo_list.getSelectionModel().getSelectedIndex();
            Photo photoCurr = MyAlbum.getPhotos().get(Index);
            for(int i=0; i<MyUser.getAlbums().size(); i++){
                Album albumCurr = MyUser.getAlbums().get(i);
                if(albumCurr.checkPhotoExist(photoCurr.getFilePath())){
                    albumCurr.getCurrentPhoto().renameCaption(caption);
                }
            }
            updatelist();
            details();

        }
    }

    public void DeletePhoto (ActionEvent e){
        if(Photo_list.getSelectionModel().getSelectedIndex() == -1){
            Alert alert = new Alert(Alert.AlertType.ERROR);
            alert.setTitle("Delete Photo Error Message");
            alert.setHeaderText("Error");
            alert.setContentText("Please Select Photo to Delete");
            alert.showAndWait();
            return;
        }

        Alert confirm = new Alert(Alert.AlertType.CONFIRMATION);
        confirm.setTitle("Confirmation");
        confirm.setHeaderText("Delete selected Photo?");
        Optional<ButtonType> result = confirm.showAndWait();

        if(result.isPresent() && result.get() == ButtonType.OK)
        {
            int removePhotoIndex = Photo_list.getSelectionModel().getSelectedIndex();
            MyAlbum.deletePhoto(removePhotoIndex);
            updatelist();
            details();
        }
    }

    public void SlideShow (ActionEvent e) throws IOException {
        if (PhotosList.size() == 0) {
            Alert alert = new Alert(Alert.AlertType.ERROR);
            alert.setTitle("Slideshow Error");
            alert.setHeaderText("Error");
            alert.setHeaderText("No Photos to Display.");
            alert.showAndWait();
            return;
        }
        SlideShowController.MyAlbum = MyAlbum;
        FXMLLoader loader = new FXMLLoader();
        loader.setLocation(getClass().getResource("/lib/view/SlideShow.fxml"));
        VBox root = (VBox) loader.load();

        Scene scene = new Scene(root);
        Photos.mainStage.setScene(scene);
        Photos.mainStage.setTitle("SlideShow Screen");
        Photos.mainStage.setResizable(true);
        Photos.mainStage.show();
        SlideShowController SlideShowController = loader.getController();
        SlideShowController.start();
    }

    public void RemoveTag (ActionEvent e){
        Alert alert = new Alert(Alert.AlertType.ERROR);
        if(Photo_list.getSelectionModel().getSelectedIndex() == -1){
            alert.setTitle("Remove Tag Error Message");
            alert.setHeaderText("Error");
            alert.setContentText("Please Select Photo to Remove Tag");
            alert.showAndWait();
            return;
        }

        if(Tag_list.getSelectionModel().getSelectedIndex() == -1){
            alert.setTitle("Remove Tag Error Message");
            alert.setHeaderText("Error");
            alert.setContentText("Please Select Tag to Remove");
            alert.showAndWait();
            return;
        }

        Alert confirm = new Alert(Alert.AlertType.CONFIRMATION);
        confirm.setTitle("Confirmation");
        confirm.setHeaderText("Delete selected Tag?");
        Optional<ButtonType> result = confirm.showAndWait();


        if(result.isPresent() && result.get() == ButtonType.OK)
        {
            int Index = Photo_list.getSelectionModel().getSelectedIndex();
            int removeTagIndex = Tag_list.getSelectionModel().getSelectedIndex();
            Tag temp = Tag_list.getSelectionModel().getSelectedItem();
            Photo photoCurr = MyAlbum.getPhotos().get(Index);
            for(int i=0; i<MyUser.getAlbums().size(); i++){
                Album albumCurr = MyUser.getAlbums().get(i);
                if(albumCurr.checkPhotoExist(photoCurr.getFilePath())){
                    albumCurr.getCurrentPhoto().removeTag(temp.getType(),temp.getValue());
                }
            }
        }
        updatelist();
        details();
    }

    public void MovePhoto (ActionEvent e){
        Alert alert = new Alert(Alert.AlertType.ERROR);
        if(Photo_list.getSelectionModel().getSelectedIndex() == -1){
            alert.setTitle("Move Photo Error Message");
            alert.setHeaderText("Error");
            alert.setContentText("Please Select Photo to Move to another Album");
            alert.showAndWait();
            return;
        }

        String album = Album_MoveCopy.getText().trim();
        if(album.isEmpty() || album == null) {
            alert.setTitle("Move Photo Error Message");
            alert.setHeaderText("Error");
            alert.setContentText("Please Enter an Album Name to Move Photo");
            alert.showAndWait();
            return;
        } else if(MyUser.checkAlbumExist(album)){
            for(int i=0; i<MyUser.getAlbums().size(); i++){
                if(MyUser.getAlbums().get(i).getAlbumName().equals(album)){
                    int PhotoIndex = Photo_list.getSelectionModel().getSelectedIndex();
                    Photo curr = MyAlbum.getPhotos().get(PhotoIndex);

                    if (MyUser.getAlbums().get(i).checkPhotoExist(curr.getFilePath())){
                        alert.setTitle("Move Photo Error Message");
                        alert.setHeaderText("Error");
                        alert.setContentText("Photo already exists in requested album");
                        alert.showAndWait();
                        return;
                    }

                    Alert confirm = new Alert(Alert.AlertType.CONFIRMATION);
                    confirm.setTitle("Confirmation");
                    confirm.setHeaderText("Move selected Photo?");
                    Optional<ButtonType> result = confirm.showAndWait();

                    if(result.isPresent() && result.get() == ButtonType.OK)
                    {
                    MyUser.getAlbums().get(i).addPhoto(curr);
                    MyAlbum.deletePhoto(PhotoIndex);
                    updatelist();
                    details();
                    }
                }
            }

        } else{
            alert.setTitle("Move Photo Error Message");
            alert.setHeaderText("Error");
            alert.setContentText("Album doesn't exist. Enter another Album Name to Move Photo");
            alert.showAndWait();
            return;
        }
    }

    public void CopyPhoto (ActionEvent e){
        Alert alert = new Alert(Alert.AlertType.ERROR);
        if(Photo_list.getSelectionModel().getSelectedIndex() == -1){
            alert.setTitle("Copy Photo Error Message");
            alert.setHeaderText("Error");
            alert.setContentText("Please Select Photo to Copy to another Album");
            alert.showAndWait();
            return;
        }

        String album = Album_MoveCopy.getText().trim();
        if(album.isEmpty() || album == null) {
            alert.setTitle("Copy Photo Error Message");
            alert.setHeaderText("Error");
            alert.setContentText("Please Enter an Album Name to Copy Photo");
            alert.showAndWait();
            return;
        } else if(MyUser.checkAlbumExist(album)){
            for(int i=0; i<MyUser.getAlbums().size(); i++){
                if(MyUser.getAlbums().get(i).getAlbumName().equals(album)){
                    int PhotoIndex = Photo_list.getSelectionModel().getSelectedIndex();
                    Photo curr = MyAlbum.getPhotos().get(PhotoIndex);

                    if (MyUser.getAlbums().get(i).checkPhotoExist(curr.getFilePath())){
                        alert.setTitle("Copy Photo Error Message");
                        alert.setHeaderText("Error");
                        alert.setContentText("Photo already exists in requested album");
                        alert.showAndWait();
                        return;
                    }

                    Alert confirm = new Alert(Alert.AlertType.CONFIRMATION);
                    confirm.setTitle("Confirmation");
                    confirm.setHeaderText("Copy selected Photo?");
                    Optional<ButtonType> result = confirm.showAndWait();

                    if(result.isPresent() && result.get() == ButtonType.OK)
                    {
                        Photo newphoto = new Photo(curr.getPic(), curr.getFilePath(), curr.getStock());
                        newphoto.renameCaption(curr.getCaption());
                        newphoto.setTags(curr.getTags());
                        newphoto.setDate(curr.getDate());
                        MyUser.getAlbums().get(i).addPhoto(newphoto);
                        updatelist();
                        details();
                    }
                }
            }

        } else{
            alert.setTitle("Copy Photo Error Message");
            alert.setHeaderText("Error");
            alert.setContentText("Album doesn't exist. Enter another Album Name to Copy Photo");
            alert.showAndWait();
            return;
        }
    }
}
