package lib.controller;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;
import lib.model.Admin;
import lib.App.Photos;


import java.io.*;
import java.util.ArrayList;
import java.util.Optional;

/**
 * @author Akhil Mohammed
 * @author Yara Hanafi
 *
 */

public class AdminController {
    @FXML ListView<String> User_list;

    @FXML TextField Add_User;

    @FXML Button Quit_button;
    @FXML Button Logout_button;
    @FXML Button AddUser_button;
    @FXML Button DeleteUser_button;

    private ArrayList<String> usersList = new ArrayList<String>();
    private ObservableList<String> obsList;
    public static Admin admin = Photos.adminMain;


    public void start() {
        updatelist();
    }


    public void updatelist() {
        usersList.clear();

        for(int i=0; i<admin.getUsers().size(); i++){
            usersList.add(admin.getUsers().get(i).getName());
        }

        obsList = FXCollections.observableArrayList(usersList);
        User_list.setItems(obsList);

    }

    public void AddUser(ActionEvent e) throws IOException {
        String UserName = Add_User.getText().trim();
        Alert alert = new Alert(Alert.AlertType.ERROR);

        if(UserName.isEmpty() || UserName == null) {
            alert.setTitle("AddUser Error Message");
            alert.setHeaderText("Error");
            alert.setContentText("Please Enter a Username");
            alert.showAndWait();
            return;
        } else if(UserName.equals("admin")){
            alert.setTitle("AddUser Error Message");
            alert.setHeaderText("Error");
            alert.setContentText("Cannot use 'admin' as User");
            alert.showAndWait();
            return;
        }
        else if(admin.checkUserExist(UserName)){
            alert.setTitle("AddUser Error Message");
            alert.setHeaderText("Error");
            alert.setContentText("User already exists. Use different Username");
            alert.showAndWait();
            return;
        } else {
            admin.addUser(UserName);
            updatelist();
        }
        Admin.Save(admin);
    }

    public void DeleteUser(ActionEvent e){
        if(User_list.getSelectionModel().getSelectedIndex() == -1){
            Alert alert = new Alert(Alert.AlertType.ERROR);
            alert.setTitle("Delete User Error Message");
            alert.setHeaderText("Error");
            alert.setContentText("Please Select User to Delete");
            alert.showAndWait();
            return;
        }

        Alert confirm = new Alert(Alert.AlertType.CONFIRMATION);
        confirm.setTitle("Confirmation");
        confirm.setHeaderText("Delete selected user?");
        Optional<ButtonType> result = confirm.showAndWait();

        if(result.isPresent() && result.get() == ButtonType.OK)
        {
            int removeUserIndex = User_list.getSelectionModel().getSelectedIndex();
            admin.deleteUser(removeUserIndex);
            updatelist();
        }
    }

    public void Quit(ActionEvent e){
        try {
            Admin.Save(admin);
        } catch (IOException a) {
            a.printStackTrace();
        }
        Stage stage = (Stage) Quit_button.getScene().getWindow();
        stage.close();
    }

    public void Logout(ActionEvent e) throws IOException {
        Alert alert = new Alert(Alert.AlertType.CONFIRMATION);
        alert.setTitle("Logout Confirmation");
        alert.setHeaderText("Confirm");
        alert.setContentText("Are you sure you want to logout?");

        Optional<ButtonType> result = alert.showAndWait();
        if (result.get() == ButtonType.OK) {
            Admin.Save(admin);
            FXMLLoader loader = new FXMLLoader();
            loader.setLocation(getClass().getResource("/lib/view/Login.fxml"));
            VBox root = (VBox) loader.load();

            Scene scene = new Scene(root);
            Photos.mainStage.setScene(scene);
            Photos.mainStage.setTitle("Login Screen");
            Photos.mainStage.setResizable(true);
            Photos.mainStage.show();
        } else {
            return;
        }
    }
}
