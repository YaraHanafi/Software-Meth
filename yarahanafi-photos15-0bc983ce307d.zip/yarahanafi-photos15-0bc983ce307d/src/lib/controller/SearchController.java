package lib.controller;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;
import lib.App.Photos;
import lib.model.*;

import java.io.*;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.Optional;

/**
 * @author Akhil Mohammed
 * @author Yara Hanafi
 *
 */

public class SearchController {

    @FXML Button Quit_button;
    @FXML Button Logout_button;
    @FXML Button SearchDate_button;
    @FXML Button SearchAndTags_button;
    @FXML Button SearchOrTags_button;
    @FXML Button SearchTag_button;
    @FXML Button CreateAlbum_button;
    @FXML Button Back_button;

    @FXML ListView<Photo> PhotoSearch_list;

    @FXML TextField Tag1_Type;
    @FXML TextField Tag1_Value;
    @FXML TextField Tag2_Type;
    @FXML TextField Tag2_Value;
    @FXML TextField Create_Album;

    @FXML DatePicker Date_Start;
    @FXML DatePicker Date_End;

    public static User MyUser;
    private ArrayList<Photo> PhotosList = new ArrayList<Photo>();
    private ObservableList<Photo> obsList;
    public static Admin admin = Photos.adminMain;

    public void start() throws FileNotFoundException {
        allphotos();

        updatelist();
    }

    public void allphotos(){
        PhotosList.clear();

        for(int i=0; i<MyUser.getAlbums().size(); i++){
            Album albumCurr = MyUser.getAlbums().get(i);
            for(int j=0; j<albumCurr.getPhotos().size(); j++){
                if(!check(albumCurr.getPhotos().get(j))) {
                    PhotosList.add(albumCurr.getPhotos().get(j));
                }
            }
        }
    }

    public void updatelist() {

        obsList = FXCollections.observableArrayList(PhotosList);
        PhotoSearch_list.setItems(obsList);

        PhotoSearch_list.setCellFactory(param -> new ListCell<Photo>() {
            private ImageView imageView = new ImageView();
            @Override
            public void updateItem(Photo photo, boolean empty) {
                super.updateItem(photo, empty);
                if (empty) {
                    setText(null);
                    setGraphic(null);
                } else {
                    Image image = new Image(photo.getPic().toURI().toString());
                    imageView.setImage(image);
                    imageView.setFitHeight(50);
                    imageView.setFitWidth(50);
                    setText(photo.getCaption());
                    setGraphic(imageView);

                }
            }
        });

    }

    private boolean check(Photo photo){
        for(int i=0; i<PhotosList.size(); i++){
            if(PhotosList.get(i).getFilePath().equals(photo.getFilePath())){
                return true;
            }
        }
        return false;
    }

    public void Quit(ActionEvent e){
        try {
            Admin.Save(admin);
        } catch (IOException a) {
            a.printStackTrace();
        }
        Stage stage = (Stage) Quit_button.getScene().getWindow();
        stage.close();
    }

    public void Logout(ActionEvent e) throws IOException {
        Alert alert = new Alert(Alert.AlertType.CONFIRMATION);
        alert.setTitle("Logout Confirmation");
        alert.setHeaderText("Confirm");
        alert.setContentText("Are you sure you want to logout?");

        Optional<ButtonType> result = alert.showAndWait();
        if (result.get() == ButtonType.OK) {
            Admin.Save(admin);
            FXMLLoader loader = new FXMLLoader();
            loader.setLocation(getClass().getResource("/lib/view/Login.fxml"));
            VBox root = (VBox) loader.load();

            Scene scene = new Scene(root);
            Photos.mainStage.setScene(scene);
            Photos.mainStage.setTitle("Login Screen");
            Photos.mainStage.setResizable(true);
            Photos.mainStage.show();
        } else {
            return;
        }
    }

    public void SearchDate (ActionEvent e){
        allphotos();
        LocalDate Start = Date_Start.getValue();
        LocalDate End = Date_End.getValue();

        Alert alert = new Alert(Alert.AlertType.ERROR);
        if (PhotosList.size() == 0) {
            alert.setTitle("Search Date Error");
            alert.setHeaderText("Error");
            alert.setHeaderText("No Photos to Search.");
            alert.showAndWait();
            return;
        }

        if(Start==null && End == null) {
            alert.setTitle("Search Date Message");
            alert.setHeaderText("Error");
            alert.setContentText("Please Enter a Start and End Date to Search");
            alert.showAndWait();
            return;
        }

        if(Start==null) {
            alert.setTitle("Search Date Message");
            alert.setHeaderText("Error");
            alert.setContentText("Please Enter a Start Date to Search");
            alert.showAndWait();
            return;
        }

        if(End==null) {
            alert.setTitle("Search Date Message");
            alert.setHeaderText("Error");
            alert.setContentText("Please Enter an End Date to Search");
            alert.showAndWait();
            return;
        }

        if(End.isBefore(Start)) {
            alert.setTitle("Search Date Message");
            alert.setHeaderText("Error");
            alert.setContentText("The Start date should be before the End date.");
            alert.showAndWait();
            return;
        }

        ArrayList<Photo> range = new ArrayList<Photo>();

        Calendar StartDate = Calendar.getInstance();
        StartDate.set(Start.getYear(), Start.getMonthValue(), Start.getDayOfMonth());

        Calendar EndDate = Calendar.getInstance();
        EndDate.set(End.getYear(), End.getMonthValue(), End.getDayOfMonth());

        for(int i=0; i<PhotosList.size(); i++){
            Date PhotoDate = PhotosList.get(i).getDate();
            Calendar ate = Calendar.getInstance();
            ate.setTime(PhotoDate);

            Calendar today = Calendar.getInstance();

            int year = ate.get(Calendar.YEAR);
            int month = ate.get(Calendar.MONTH)+1;
            int day = ate.get(Calendar.DAY_OF_MONTH);

            today.set(year, month, day);
            if((today.compareTo(StartDate) > 0 && today.compareTo(EndDate) < 0) || today.equals(StartDate) || today.equals(EndDate)) {
                range.add(PhotosList.get(i));
            }
        }

        PhotosList = range;
        updatelist();

    }

    public void SearchAndTags(ActionEvent e){
        allphotos();
        String Type1 = Tag1_Type.getText().trim();
        String Value1 = Tag1_Value.getText().trim();
        String Type2 = Tag2_Type.getText().trim();
        String Value2 = Tag2_Value.getText().trim();
        Alert alert = new Alert(Alert.AlertType.ERROR);

        if (PhotosList.size() == 0) {
            alert.setTitle("Search Tag Error");
            alert.setHeaderText("Error");
            alert.setHeaderText("No Photos to Search.");
            alert.showAndWait();
            return;
        }

        if((Type1==null && Value1 == null) ||(Type1.isEmpty() && Value1.isEmpty()) || (Type2==null && Value2 == null) ||(Type2.isEmpty() && Value2.isEmpty()) ) {
            alert.setTitle("Search Tag Error");
            alert.setHeaderText("Error");
            alert.setContentText("Please Enter Type and Value to Search Tag");
            alert.showAndWait();
            return;
        }

        if(Type1==null || Type1.isEmpty() || Type2==null || Type2.isEmpty() ) {
            alert.setTitle("Search Tag Message");
            alert.setHeaderText("Error");
            alert.setContentText("Please Enter Type to Search Tag");
            alert.showAndWait();
            return;
        }

        if(Value1==null || Value1.isEmpty() || Value2==null || Value2.isEmpty()) {
            alert.setTitle("Search Tag Message");
            alert.setHeaderText("Error");
            alert.setContentText("Please Enter Value to Search Tag");
            alert.showAndWait();
            return;
        }
        ArrayList<Photo> tags = new ArrayList<Photo>();
        for(int i=0; i<PhotosList.size(); i++){
            Photo curr = PhotosList.get(i);
            if(curr.checkTagExist(Type1,Value1) && curr.checkTagExist(Type2,Value2)){
                tags.add(curr);
            }
        }

        PhotosList = tags;
        updatelist();
    }

    public void SearchOrTags(ActionEvent e){
        allphotos();
        String Type1 = Tag1_Type.getText().trim();
        String Value1 = Tag1_Value.getText().trim();
        String Type2 = Tag2_Type.getText().trim();
        String Value2 = Tag2_Value.getText().trim();
        Alert alert = new Alert(Alert.AlertType.ERROR);

        if (PhotosList.size() == 0) {
            alert.setTitle("Search Tag Error");
            alert.setHeaderText("Error");
            alert.setHeaderText("No Photos to Search.");
            alert.showAndWait();
            return;
        }

        if((Type1==null && Value1 == null) ||(Type1.isEmpty() && Value1.isEmpty()) || (Type2==null && Value2 == null) ||(Type2.isEmpty() && Value2.isEmpty()) ) {
            alert.setTitle("Search Tag Error");
            alert.setHeaderText("Error");
            alert.setContentText("Please Enter Type and Value to Search Tag");
            alert.showAndWait();
            return;
        }

        if(Type1==null || Type1.isEmpty() || Type2==null || Type2.isEmpty() ) {
            alert.setTitle("Search Tag Message");
            alert.setHeaderText("Error");
            alert.setContentText("Please Enter Type to Search Tag");
            alert.showAndWait();
            return;
        }

        if(Value1==null || Value1.isEmpty() || Value2==null || Value2.isEmpty()) {
            alert.setTitle("Search Tag Message");
            alert.setHeaderText("Error");
            alert.setContentText("Please Enter Value to Search Tag");
            alert.showAndWait();
            return;
        }
        ArrayList<Photo> tags = new ArrayList<Photo>();
        for(int i=0; i<PhotosList.size(); i++){
            Photo curr = PhotosList.get(i);
            if(curr.checkTagExist(Type1,Value1) || curr.checkTagExist(Type2,Value2)){
                tags.add(curr);
            }
        }

        PhotosList = tags;
        updatelist();
    }

    public void SearchTag(ActionEvent e){
        allphotos();
        String Type = Tag1_Type.getText().trim();
        String Value = Tag1_Value.getText().trim();
        Alert alert = new Alert(Alert.AlertType.ERROR);

        if (PhotosList.size() == 0) {
            alert.setTitle("Search Tag Error");
            alert.setHeaderText("Error");
            alert.setHeaderText("No Photos to Search.");
            alert.showAndWait();
            return;
        }

        if((Type==null && Value == null) ||(Type.isEmpty() && Value.isEmpty()) ) {
            alert.setTitle("Search Tag Error");
            alert.setHeaderText("Error");
            alert.setContentText("Please Enter a Type and Value to Search Tag");
            alert.showAndWait();
            return;
        }

        if(Type==null || Type.isEmpty() ) {
            alert.setTitle("Search Tag Message");
            alert.setHeaderText("Error");
            alert.setContentText("Please Enter a Type to Search Tag");
            alert.showAndWait();
            return;
        }

        if(Value==null || Value.isEmpty() ) {
            alert.setTitle("Search Tag Message");
            alert.setHeaderText("Error");
            alert.setContentText("Please Enter a Value to Search Tag");
            alert.showAndWait();
            return;
        }
        ArrayList<Photo> tags = new ArrayList<Photo>();
        for(int i=0; i<PhotosList.size(); i++){
            Photo curr = PhotosList.get(i);
            if(curr.checkTagExist(Type,Value)){
                tags.add(curr);
            }
        }

        PhotosList = tags;
        updatelist();

    }

    public void CreateAlbum(ActionEvent e) throws IOException {
        String CreateAlbum = Create_Album.getText().trim();
        Alert alert = new Alert(Alert.AlertType.ERROR);

        if(CreateAlbum.isEmpty() || CreateAlbum == null) {
            alert.setTitle("Create Album Error Message");
            alert.setHeaderText("Error");
            alert.setContentText("Please Enter an Album Name to Create");
            alert.showAndWait();
            return;
        } else if(MyUser.checkAlbumExist(CreateAlbum)){
            alert.setTitle("Create Album Error Message");
            alert.setHeaderText("Error");
            alert.setContentText("Album already exists. Use different Album Name");
            alert.showAndWait();
            return;
        } else {
            Alert alert1 = new Alert(Alert.AlertType.CONFIRMATION);
            alert1.setTitle("Create Album Confirmation");
            alert1.setHeaderText("Confirm");
            alert1.setContentText("Create Album from Photos in List?");

            Optional<ButtonType> result = alert1.showAndWait();
            if (result.get() == ButtonType.OK) {
                Album create = new Album(CreateAlbum);
                for(int i=0; i<PhotosList.size(); i++) {
                    Photo newphoto = new Photo(PhotosList.get(i).getPic(), PhotosList.get(i).getFilePath(), PhotosList.get(i).getStock());
                    newphoto.renameCaption(PhotosList.get(i).getCaption());
                    newphoto.setTags(PhotosList.get(i).getTags());
                    newphoto.setDate(PhotosList.get(i).getDate());
                    create.addPhoto(newphoto);
                }
                MyUser.addAlbum(create);
            } else {
                return;
            }
        }
        Admin.Save(admin);
    }

    public void Back(ActionEvent e) throws IOException {
        AlbumController.MyUser = MyUser;
        FXMLLoader loader = new FXMLLoader();
        loader.setLocation(getClass().getResource("/lib/view/Album.fxml"));
        VBox root = (VBox) loader.load();

        Scene scene = new Scene(root);
        Photos.mainStage.setScene(scene);
        Photos.mainStage.setTitle("Album Screen");
        Photos.mainStage.setResizable(true);
        Photos.mainStage.show();
        AlbumController albumController = loader.getController();
        albumController.start();
    }
}
