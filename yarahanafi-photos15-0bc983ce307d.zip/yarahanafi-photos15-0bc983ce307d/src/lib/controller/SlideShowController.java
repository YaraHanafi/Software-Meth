package lib.controller;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.ButtonType;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;
import lib.App.Photos;
import lib.model.Admin;
import lib.model.Album;
import lib.model.Photo;

import java.io.*;
import java.util.ArrayList;
import java.util.Optional;

/**
 * @author Akhil Mohammed
 * @author Yara Hanafi
 *
 */

public class SlideShowController {
    @FXML Button Quit_button;
    @FXML Button Logout_button;
    @FXML Button Forward_button;
    @FXML Button Backward_button;
    @FXML Button Back_button;

    @FXML ImageView Imageview;

    public static Album MyAlbum;
    public static Admin admin = Photos.adminMain;
    private ArrayList<Photo> list = MyAlbum.getPhotos();
    private int Index=0;

    public void start() throws FileNotFoundException {
        Imageview.setImage(new Image(list.get(0).getPic().toURI().toString()));
    }

    public void Quit(ActionEvent e){
        try {
            Admin.Save(admin);
        } catch (IOException a) {
            a.printStackTrace();
        }
        Stage stage = (Stage) Quit_button.getScene().getWindow();
        stage.close();
    }

    public void Logout(ActionEvent e) throws IOException {
        Alert alert = new Alert(Alert.AlertType.CONFIRMATION);
        alert.setTitle("Logout Confirmation");
        alert.setHeaderText("Confirm");
        alert.setContentText("Are you sure you want to logout?");

        Optional<ButtonType> result = alert.showAndWait();
        if (result.get() == ButtonType.OK) {
            Admin.Save(admin);
            FXMLLoader loader = new FXMLLoader();
            loader.setLocation(getClass().getResource("/lib/view/Login.fxml"));
            VBox root = (VBox) loader.load();

            Scene scene = new Scene(root);
            Photos.mainStage.setScene(scene);
            Photos.mainStage.setTitle("Login Screen");
            Photos.mainStage.setResizable(true);
            Photos.mainStage.show();
        } else {
            return;
        }
    }

    public void Forward(ActionEvent e){
        Index++;
        if(Index < list.size()){
            Imageview.setImage(new Image(list.get(Index).getPic().toURI().toString()));
        } else {
            Alert alert = new Alert(Alert.AlertType.ERROR);
            alert.setTitle("SlideShow Error Message");
            alert.setHeaderText("Error");
            alert.setContentText("Reached End of Photos SlideShow. Cannot move Forward");
            alert.showAndWait();
        }
    }

    public void Backward (ActionEvent e){
        Index--;
        if(Index >= 0){
            Imageview.setImage(new Image(list.get(Index).getPic().toURI().toString()));
        } else {
            Alert alert = new Alert(Alert.AlertType.ERROR);
            alert.setTitle("SlideShow Error Message");
            alert.setHeaderText("Error");
            alert.setContentText("Reached Start of Photos SlideShow. Cannot move Backward Further");
            alert.showAndWait();
        }
    }

    public void Back (ActionEvent e) throws IOException {
        FXMLLoader loader = new FXMLLoader();
        loader.setLocation(getClass().getResource("/lib/view/Photo.fxml"));
        VBox root = (VBox) loader.load();

        Scene scene = new Scene(root);
        Photos.mainStage.setScene(scene);
        Photos.mainStage.setTitle("Photo Screen");
        Photos.mainStage.setResizable(true);
        Photos.mainStage.show();
        PhotoController photoController = loader.getController();
        photoController.start();
    }
}
