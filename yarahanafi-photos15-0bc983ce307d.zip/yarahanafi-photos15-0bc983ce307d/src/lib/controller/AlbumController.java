package lib.controller;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;
import lib.App.Photos;
import lib.model.Admin;
import lib.model.Album;
import lib.model.User;

import java.io.*;
import java.util.ArrayList;
import java.util.Optional;

/**
 * @author Akhil Mohammed
 * @author Yara Hanafi
 *
 */

public class AlbumController {
    @FXML Button Quit_button;
    @FXML Button Logout_button;
    @FXML Button DeleteAlbum_button;
    @FXML Button AddAlbum_button;
    @FXML Button OpenAlbum_button;
    @FXML Button RenameAlbum_button;
    @FXML Button Search_button;

    @FXML ListView<Album> Album_list;

    @FXML TextField Rename_Album;
    @FXML TextField New_Album;

    @FXML Label AlbumName;
    @FXML Label AlbumNumber;
    @FXML Label AlbumDate;


    public static User MyUser;
    private ArrayList<Album> albumsList = new ArrayList<Album>();
    private ObservableList<Album> obsList;
    public static Admin admin = Photos.adminMain;

    public void start() throws FileNotFoundException {
        updatelist();
        Album_list.getSelectionModel().select(0);
        details();
        //listener
        Album_list.getSelectionModel().selectedIndexProperty().addListener(
                (obs,oldVal, newVal) ->
                        details());
    }

    public void details(){
        Album CurrAlbum = Album_list.getSelectionModel().getSelectedItem();
        if (CurrAlbum != null) {
            AlbumName.setText(CurrAlbum.getAlbumName());
            AlbumNumber.setText(CurrAlbum.getCount());
            AlbumDate.setText(CurrAlbum.getFirstDate() + " - " + CurrAlbum.getLastDate());
        } else{
            AlbumName.setText("");
            AlbumNumber.setText("");
            AlbumDate.setText("");
        }
    }

    public void updatelist() {
        albumsList.clear();

        for(int i=0; i<MyUser.getAlbums().size(); i++){
            albumsList.add(MyUser.getAlbums().get(i));
        }

        obsList = FXCollections.observableArrayList(albumsList);
        Album_list.setItems(obsList);

    }

    public void Quit(ActionEvent e){
        try {
            Admin.Save(admin);
        } catch (IOException a) {
            a.printStackTrace();
        }
        Stage stage = (Stage) Quit_button.getScene().getWindow();
        stage.close();
    }

    public void Logout(ActionEvent e) throws IOException {
        Alert alert = new Alert(Alert.AlertType.CONFIRMATION);
        alert.setTitle("Logout Confirmation");
        alert.setHeaderText("Confirm");
        alert.setContentText("Are you sure you want to logout?");

        Optional<ButtonType> result = alert.showAndWait();
        if (result.get() == ButtonType.OK) {
            Admin.Save(admin);
            FXMLLoader loader = new FXMLLoader();
            loader.setLocation(getClass().getResource("/lib/view/Login.fxml"));
            VBox root = (VBox) loader.load();

            Scene scene = new Scene(root);
            Photos.mainStage.setScene(scene);
            Photos.mainStage.setTitle("Login Screen");
            Photos.mainStage.setResizable(true);
            Photos.mainStage.show();
        } else {
            return;
        }
    }

    public void DeleteAlbum(){
        if(Album_list.getSelectionModel().getSelectedIndex() == -1){
            Alert alert = new Alert(Alert.AlertType.ERROR);
            alert.setTitle("Delete Album Error Message");
            alert.setHeaderText("Error");
            alert.setContentText("Please Select Album to Delete");
            alert.showAndWait();
            return;
        }

        Alert confirm = new Alert(Alert.AlertType.CONFIRMATION);
        confirm.setTitle("Confirmation");
        confirm.setHeaderText("Delete selected Album?");
        Optional<ButtonType> result = confirm.showAndWait();

        if(result.isPresent() && result.get() == ButtonType.OK)
        {
            int removeAlbumIndex = Album_list.getSelectionModel().getSelectedIndex();
            MyUser.deleteAlbum(removeAlbumIndex);
            updatelist();
            details();
        }
    }

    public void AddAlbum() throws IOException {
        String NewAlbum = New_Album.getText().trim();
        Alert alert = new Alert(Alert.AlertType.ERROR);

        if(NewAlbum.isEmpty() || NewAlbum == null) {
            alert.setTitle("New Album Error Message");
            alert.setHeaderText("Error");
            alert.setContentText("Please Enter an Album Name");
            alert.showAndWait();
            return;
        } else if(MyUser.checkAlbumExist(NewAlbum)){
            alert.setTitle("New Album Error Message");
            alert.setHeaderText("Error");
            alert.setContentText("Album already exists. Use different Album Name");
            alert.showAndWait();
            return;
        } else {
            MyUser.addAlbum(new Album(NewAlbum));
            updatelist();
        }
        Admin.Save(admin);
    }

    public void OpenAlbum() throws IOException {
        if(Album_list.getSelectionModel().getSelectedIndex() == -1){
            Alert alert = new Alert(Alert.AlertType.ERROR);
            alert.setTitle("Open Album Error Message");
            alert.setHeaderText("Error");
            alert.setContentText("Please Select Album to Open");
            alert.showAndWait();
            return;
        }

        int indexSelect = Album_list.getSelectionModel().getSelectedIndex();
        Album currentAlbum = MyUser.getAlbums().get(indexSelect);
        PhotoController.MyAlbum = currentAlbum;
        PhotoController.MyUser = MyUser;
        FXMLLoader loader = new FXMLLoader();
        loader.setLocation(getClass().getResource("/lib/view/Photo.fxml"));
        VBox root = (VBox) loader.load();

        Scene scene = new Scene(root);
        Photos.mainStage.setScene(scene);
        Photos.mainStage.setTitle("Photo Screen");
        Photos.mainStage.setResizable(true);
        Photos.mainStage.show();
        PhotoController photoController = loader.getController();
        photoController.start();
    }

    public void RenameAlbum() throws IOException {
        String NewName = Rename_Album.getText().trim();
        Alert alert = new Alert(Alert.AlertType.ERROR);

        if(Album_list.getSelectionModel().getSelectedIndex() == -1){
            alert.setTitle("Rename Album Error Message");
            alert.setHeaderText("Error");
            alert.setContentText("Please Select Album to Rename");
            alert.showAndWait();
            return;
        }

        if(NewName.isEmpty() || NewName == null) {
            alert.setTitle("Rename Album Error Message");
            alert.setHeaderText("Error");
            alert.setContentText("Please Enter an Album Name to Rename");
            alert.showAndWait();
            return;
        } else if(MyUser.checkAlbumExist(NewName)){
            alert.setTitle("Rename Album Error Message");
            alert.setHeaderText("Error");
            alert.setContentText("Album already exists. Use different Album Name to Rename");
            alert.showAndWait();
            return;
        } else {
            int AlbumIndex = Album_list.getSelectionModel().getSelectedIndex();
            MyUser.getAlbums().get(AlbumIndex).renameAlbumName(NewName);
            updatelist();
        }
        Admin.Save(admin);
    }

    public void Search() throws IOException {
        SearchController.MyUser = MyUser;
        FXMLLoader loader = new FXMLLoader();
        loader.setLocation(getClass().getResource("/lib/view/Search.fxml"));
        VBox root = (VBox) loader.load();

        Scene scene = new Scene(root);
        Photos.mainStage.setScene(scene);
        Photos.mainStage.setTitle("Search Screen");
        Photos.mainStage.setResizable(true);
        Photos.mainStage.show();
        SearchController searchController = loader.getController();
        searchController.start();
    }
}
