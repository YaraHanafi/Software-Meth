package lib.controller;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;
import lib.App.Photos;
import lib.model.Admin;
import lib.model.User;

import java.io.*;

/**
 * @author Akhil Mohammed
 * @author Yara Hanafi
 *
 */

public class LoginController {
    @FXML TextField UserName;

    @FXML Button Quit_button;
    @FXML Button Login_button;

    public static Admin admin = Photos.adminMain;


    public void Quit(ActionEvent e){
        try {
            Admin.Save(admin);
        } catch (IOException a) {
            a.printStackTrace();
        }
        Stage stage = (Stage) Quit_button.getScene().getWindow();
        stage.close();
    }

    public void Login(ActionEvent e) throws IOException {
        String user = UserName.getText().trim();

        if(user.equals("admin")){
            FXMLLoader loader = new FXMLLoader();
            loader.setLocation(getClass().getResource("/lib/view/Admin.fxml"));
            VBox root = (VBox) loader.load();

            Scene scene = new Scene(root);
            Photos.mainStage.setScene(scene);
            Photos.mainStage.setTitle("Admin Screen");
            Photos.mainStage.setResizable(true);
            Photos.mainStage.show();
            AdminController adminController = loader.getController();
            adminController.start();
        } else if (admin.checkUserExist(user)){
            User currentUser = admin.getCurrentUser();
            AlbumController.MyUser = currentUser;
            FXMLLoader loader = new FXMLLoader();
            loader.setLocation(getClass().getResource("/lib/view/Album.fxml"));
            VBox root = (VBox) loader.load();

            Scene scene = new Scene(root);
            Photos.mainStage.setScene(scene);
            Photos.mainStage.setTitle("Album Screen");
            Photos.mainStage.setResizable(true);
            Photos.mainStage.show();
            AlbumController albumController = loader.getController();
            albumController.start();
        } else if(user.isEmpty() || user == null){
            Alert alert = new Alert(Alert.AlertType.ERROR);

            alert.setTitle("Username Error Message");
            alert.setHeaderText("Error");
            alert.setContentText("Please Enter a Username");
            alert.showAndWait();
        } else{
            Alert alert = new Alert(Alert.AlertType.ERROR);

            alert.setTitle("No User Found Error Message");
            alert.setHeaderText("Error");
            alert.setContentText("Username does not Exist");
            alert.showAndWait();
        }
    }
}
