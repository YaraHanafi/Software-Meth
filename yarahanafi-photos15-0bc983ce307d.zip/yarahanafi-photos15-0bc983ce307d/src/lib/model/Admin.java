package lib.model;

import java.io.*;
import java.util.ArrayList;

/**
 * @author Akhil Mohammed
 * @author Yara Hanafi
 *
 */

public class Admin implements Serializable {

    private static final long serialVersionUID = 1L;

    public ArrayList<User> Users;
    public User CurrentUser;

    public static final String storeDir = "data";
    public static final String storeFile = "Users.data";



    public Admin() {
        Users = new ArrayList<User>();
        this.CurrentUser= null;

    }


    public void addUser(String name) {
        Users.add(new User(name));
    }


    public void deleteUser(int index) {
        Users.remove(index);
    }

    public boolean checkUserExist(String name) {
        for (int i = 0; i < Users.size(); i++) {
            if (Users.get(i).getName().equals(name)) {
                setCurrentUser(Users.get(i));
                return true;
            }
        }
        return false;
    }


    public ArrayList<User> getUsers(){
        return Users;
    }



    public User getCurrentUser() {
        return CurrentUser;
    }


    public void setCurrentUser(User currentUser) {
        this.CurrentUser = currentUser;
    }

    //saving to dat file
    public static void Save(Admin pApp) throws IOException {
            ObjectOutputStream oos = new ObjectOutputStream(new FileOutputStream(storeDir + File.separator + storeFile));
            oos.writeObject(pApp);
            oos.close();
    }

    //loading from dat file
    public static Admin Load() throws IOException, ClassNotFoundException {
        ObjectInputStream os = new ObjectInputStream(new FileInputStream(storeDir + File.separator + storeFile));
        Admin UserList = (Admin) os.readObject();
        os.close();
        return UserList;
    }

}
