package lib.model;

import java.io.*;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;

/**
 * @author Akhil Mohammed
 * @author Yara Hanafi
 *
 */

public class Album implements Serializable {

    private static final long serialVersionUID = 1L;

    public String AlbumName;
    public ArrayList<Photo> PhotoList;
    public int Count = 0;
    public Photo CurrentPhoto;

    public static final String storeDir = "data";
    public static final String storeFile = "Users.data";

    public Album(String AlbumName) {
        this.AlbumName = AlbumName;
        this.PhotoList = new ArrayList<Photo>();
    }

    public boolean checkPhotoExist(String path) {
        for(int i=0; i<PhotoList.size(); i++) {
            if(PhotoList.get(i).getFilePath().equals(path)) {
                this.setCurrentPhoto(PhotoList.get(i));
                return true;
            } else{
                this.setCurrentPhoto(null);
            }
        }
        return false;
    }


    //get the first date in photos list
    public String getFirstDate() {
        SimpleDateFormat dateFormatter = new SimpleDateFormat("E, M-d-y 'at' h:m:s a");
        Date date = null;
        String Stringdate = "No Start Date";
        if (!PhotoList.isEmpty()) {
            date = PhotoList.get(0).PhotoDate;
            for (int j=0; j<PhotoList.size(); j++) {
                if (PhotoList.get(j).PhotoDate.before(date)) {
                    date = PhotoList.get(j).PhotoDate;
                }
            }

            Stringdate = dateFormatter.format(date);
        }
            return Stringdate;
    }

    //get the last date in photos list
    public String getLastDate() {
        SimpleDateFormat dateFormatter = new SimpleDateFormat("E, M-d-y 'at' h:m:s a");
        Date date = null;
        String Stringdate = "No End Date";
        if (!PhotoList.isEmpty()) {
            date = PhotoList.get(0).PhotoDate;
            for (int j=0; j<PhotoList.size(); j++) {
                if (PhotoList.get(j).PhotoDate.after(date)) {
                    date = PhotoList.get(j).PhotoDate;
                }
            }
            Stringdate = dateFormatter.format(date);
        }
        return Stringdate;
    }


    public String getAlbumName() {
        return AlbumName;
    }

    public String getCount(){return String.valueOf(Count);}


    public void renameAlbumName(String AlbumName) {
        this.AlbumName = AlbumName;
    }


    public void addPhoto(Photo photo) {
        PhotoList.add(photo);
        Count++;
    }


    public void deletePhoto(int index) {
        PhotoList.remove(index);
        Count--;
    }


    public ArrayList<Photo> getPhotos() {
        return PhotoList;
    }


    public Photo getCurrentPhoto() {
        return CurrentPhoto;
    }


    public void setCurrentPhoto(Photo CurrentPhoto) {
        this.CurrentPhoto = CurrentPhoto;
    }


    //saving to dat file
    public static void Save(Album pApp) throws IOException {
        ObjectOutputStream os = new ObjectOutputStream(new FileOutputStream(storeDir + File.separator + storeFile));
        os.writeObject(pApp);
        os.close();
    }

    @Override
    public String toString() {
        return this.getAlbumName();
    }

}
