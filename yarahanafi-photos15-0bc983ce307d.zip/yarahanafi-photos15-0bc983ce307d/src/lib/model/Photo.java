package lib.model;

import java.io.*;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.GregorianCalendar;

/**
 * @author Akhil Mohammed
 * @author Yara Hanafi
 *
 */

public class Photo implements Serializable{

    private static final long serialVersionUID = 1L;


    public File file;
    public String Path;
    public ArrayList<Tag> Tags;
    public String Caption;
    public Date PhotoDate;
    public Boolean Stock;

    public static final String storeDir = "data";
    public static final String storeFile = "Users.data";



    public Photo(File file, String path, Boolean stock) {
        this.Path = path;
        if (file != null) {this.file = new File(path);}
        this.Stock = stock;
        this.Tags = new ArrayList<Tag>();
        this.Caption = "no caption";
        Calendar cal = new GregorianCalendar();
        cal.set(Calendar.MILLISECOND,0);
        this.PhotoDate = cal.getTime();
    }


    public void renameCaption(String Caption) {
        this.Caption = Caption;
    }


    public void SetNewTagType(String newTags){
        this.addTag(newTags," ");
    }

    public void setTags(ArrayList<Tag> listTag){
        this.Tags.clear();
        for(int i=0; i<listTag.size(); i++){
            this.Tags.add(listTag.get(i));
        }
    }

    public void addTag(String name, String value) {
        this.Tags.add(new Tag(name,value));
    }


    public void removeTag(String name, String value) {
        for(int i = 0; i < Tags.size(); i++) {
            Tag current = Tags.get(i);
            if(current.Tagname.toLowerCase().equals(name.toLowerCase()) && current.Tagvalue.toLowerCase().equals(value.toLowerCase())) {
                Tags.remove(i);
            }
        }
    }


    public boolean checkTagExist(String name, String value) {
        for(int i = 0; i < Tags.size(); i++) {
            Tag current = Tags.get(i);
            if(current.Tagname.toLowerCase().equals(name.toLowerCase()) && current.Tagvalue.toLowerCase().equals(value.toLowerCase())) {
                return true;
            }
        }
        return false;

    }


    public Date getDate() {
        return PhotoDate;
    }

    public void setDate(Date date){
        this.PhotoDate = date;
    }


    public String getDateString(){
        SimpleDateFormat dateFormatter = new SimpleDateFormat("E, M-d-y 'at' h:m:s a");
        String date = dateFormatter.format(PhotoDate);
        return date;
    }


    public ArrayList<Tag> getTags(){
        return Tags;
    }


    public String getFilePath() {
        return Path;
    }


    public File getPic() {
        return this.file;
    }

    public Boolean getStock(){return Stock;}


    public String getCaption() {
        return Caption;
    }

    //saving to dat file
    public static void Save(Photo pApp) throws IOException {
        ObjectOutputStream oos = new ObjectOutputStream(new FileOutputStream(storeDir + File.separator + storeFile));
        oos.writeObject(pApp);
        oos.close();
    }


    @Override
    public String toString() {
        return this.getCaption();
    }

}
