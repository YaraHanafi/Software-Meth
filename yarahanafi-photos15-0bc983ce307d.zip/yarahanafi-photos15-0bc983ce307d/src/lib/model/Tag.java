package lib.model;

import java.io.*;

/**
 * @author Akhil Mohammed
 * @author Yara Hanafi
 *
 */

public class Tag implements Serializable {

    public String Tagname;
    public String Tagvalue;

    public Tag(String name, String value) {
        this.Tagname = name;
        this.Tagvalue = value;
    }

    public String getType(){
        return this.Tagname;
    }

    public String getValue(){
        return this.Tagvalue;
    }


    @Override
    public String toString() {
        return this.Tagname + "," +this.Tagvalue;
    }
}
