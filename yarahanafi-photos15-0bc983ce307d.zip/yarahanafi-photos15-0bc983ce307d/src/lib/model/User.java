package lib.model;

import java.io.*;
import java.util.ArrayList;

/**
 * @author Akhil Mohammed
 * @author Yara Hanafi
 *
 */

public class User implements Serializable {

    private static final long serialVersionUID = 1L;

    public String Name;
    public ArrayList<Album> Albums;
    public ArrayList<Tag> preList = new ArrayList<Tag>();

    public static final String storeDir = "data";
    public static final String storeFile = "Users.data";


    public User(String Name) {
        this.Name = Name;
        this.Albums = new ArrayList<Album>();
        this.preList.add(new Tag("location"," "));
        this.preList.add(new Tag("person"," "));
    }


    public void addAlbum(Album album) {
        Albums.add(album);
    }

    public void deleteAlbum(int index) {
        Albums.remove(index);
    }

    public String getName() {
        return Name;
    }

    public ArrayList<Album> getAlbums() {
        return Albums;
    }


    //check if album name already exists
    public boolean checkAlbumExist(String albumname){
        for(int i= 0; i<Albums.size(); i++){
            if(albumname.equals(Albums.get(i).AlbumName)){
                return true;
            }
        }
        return false;
    }

    //Saving User to dat file
    public static void Save(User pApp) throws IOException {
        ObjectOutputStream oos = new ObjectOutputStream(new FileOutputStream(storeDir + File.separator + storeFile));
        oos.writeObject(pApp);
        oos.close();
    }


}
