package com.example.user.photos;

import android.app.ListActivity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ListView;

import java.util.ArrayList;

public class SearchResultsActivity extends ListActivity {
    private PhotoAdapter adapter;
    private ListView myListView;
    ArrayList<Photo> search_photos;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_search_results);

        myListView = getListView();

        Intent intent = getIntent();
        Bundle extras = intent.getExtras();


        if(extras != null)
            search_photos = (ArrayList<Photo>) extras.getSerializable("results");

        adapter = new PhotoAdapter(getApplicationContext(), R.layout.photo_cell, search_photos);

        myListView.setAdapter(adapter);

        myListView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> adapterView, View view, int position, long id) {
                myListView.setSelection(position);
                Photo.setCurrentPhoto(search_photos.get(position));
            }
        });
    }
}
