package com.example.user.photos;

import android.Manifest;
import android.content.DialogInterface;
import android.content.Intent;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

import android.content.pm.PackageManager;
import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.AutoCompleteTextView;
import android.widget.Button;
import android.widget.ListView;
import android.widget.Toast;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {
    private ListView albview;
    private ArrayList<Album> albumsList;

    private ArrayList<String> albumNames;

    private ArrayAdapter<Album> albumAdapter;
    private ArrayList<Photo> search_photos;
    private String[] personTags = {};
    private String[] locationTags = {};

/*
    public static void HelperMethodA ()
    {
        public void AddPhoto (ActionEvent e) throws IOException {
        FileChooser filechooser = new FileChooser();
        FileChooser.ExtensionFilter Filter = new FileChooser.ExtensionFilter("Image Files", "*.png", "*.jpg", "*.jpeg", "*.gif", "*.bmp");
        filechooser.getExtensionFilters().add(Filter);
        File image = filechooser.showOpenDialog(null);

        if (image == null) {
            return;
        } else if (MyAlbum.checkPhotoExist(image.getAbsolutePath())) {
            Alert alert = new Alert(Alert.AlertType.ERROR);
            alert.setTitle("Add Photo Error");
            alert.setHeaderText("Error");
            alert.setContentText("Photo already exists in album. Select another Photo");
            alert.showAndWait();
            return;
        }else {
            String path = image.getAbsolutePath();
            Photo addphoto;
            if(MyUser.getName().equals("stock")) {
                int index;
                if (path.contains("StockPhotos")) {
                    index = path.indexOf("StockPhotos");
                    String newpath = path.substring(index);
                    if(MyAlbum.checkPhotoExist(newpath)){
                        Alert alert = new Alert(Alert.AlertType.ERROR);
                        alert.setTitle("Add Photo Error");
                        alert.setHeaderText("Error");
                        alert.setContentText("Photo already exists in album. Select another Photo");
                        alert.showAndWait();
                        return;
                    }
                    addphoto = new Photo(image, newpath,true);
                    for(int j=0; j<MyUser.preList.size(); j++){
                        addphoto.addTag(MyUser.preList.get(j).getType(),MyUser.preList.get(j).getValue());
                    }
                    for(int i=0; i<MyUser.getAlbums().size(); i++){
                        Album albumCurr = MyUser.getAlbums().get(i);
                        if(albumCurr.checkPhotoExist(addphoto.getFilePath())){
                            addphoto.renameCaption(albumCurr.getCurrentPhoto().getCaption());
                            addphoto.setTags(albumCurr.getCurrentPhoto().getTags());
                            addphoto.setDate(albumCurr.getCurrentPhoto().getDate());
                        }
                    }
                    MyAlbum.addPhoto(addphoto);
                } else {
                    addphoto = new Photo(image, path, false);
                    for(int j=0; j<MyUser.preList.size(); j++){
                        addphoto.addTag(MyUser.preList.get(j).getType(),MyUser.preList.get(j).getValue());
                    }
                    for(int i=0; i<MyUser.getAlbums().size(); i++){
                        Album albumCurr = MyUser.getAlbums().get(i);
                        if(albumCurr.checkPhotoExist(addphoto.getFilePath())){
                            addphoto.renameCaption(albumCurr.getCurrentPhoto().getCaption());
                            addphoto.setTags(albumCurr.getCurrentPhoto().getTags());
                            addphoto.setDate(albumCurr.getCurrentPhoto().getDate());
                        }
                    }
                    MyAlbum.addPhoto(addphoto);
                }
            } else {
                addphoto = new Photo(image, path, false);
                for(int j=0; j<MyUser.preList.size(); j++){
                    addphoto.addTag(MyUser.preList.get(j).getType(),MyUser.preList.get(j).getValue());
                }
                for(int i=0; i<MyUser.getAlbums().size(); i++){
                    Album albumCurr = MyUser.getAlbums().get(i);
                    if(albumCurr.checkPhotoExist(addphoto.getFilePath())){
                        addphoto.renameCaption(albumCurr.getCurrentPhoto().getCaption());
                        addphoto.setTags(albumCurr.getCurrentPhoto().getTags());
                        addphoto.setDate(albumCurr.getCurrentPhoto().getDate());
                    }
                }
                MyAlbum.addPhoto(addphoto);
            }
            updatelist();
            Admin.Save(admin);
        }

    }
    }
*/

    private AlertDialog searchD() {

        LayoutInflater inflater = (LayoutInflater) getSystemService(LAYOUT_INFLATER_SERVICE);
        View layout = inflater.inflate(R.layout.search_layout, null, false);


        final AutoCompleteTextView personBox = (AutoCompleteTextView) layout.findViewById(R.id.personautocomplete);
        final AutoCompleteTextView locationBox = (AutoCompleteTextView) layout.findViewById(R.id.locationautocomplete);

        String[] fruits = {"Apple", "Banana", "Cherry", "Date", "Grape", "Kiwi", "Mango", "Pear"};
        ArrayAdapter<String> adapter = new ArrayAdapter<String>
                (this, android.R.layout.select_dialog_item, fruits);



        ArrayAdapter<String> peopleTagsAdapter = new ArrayAdapter<String>
                (this, android.R.layout.select_dialog_item, Album.getPeopleTagsAll());

        ArrayAdapter<String> placesTagsAdapter = new ArrayAdapter<String>
                (this, android.R.layout.select_dialog_item, Album.getPlaceTagsAll());
        personBox.setAdapter(peopleTagsAdapter);
        locationBox.setAdapter(placesTagsAdapter);

        //Building dialog
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setView(layout);
        builder.setPositiveButton("Search", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                String personString = personBox.getText().toString();

                String locationString = locationBox.getText().toString();

                boolean hasP = (personString != null && !personString.trim().equals(""));
                boolean hasL = (locationString != null && !locationString.trim().equals(""));


                ArrayList<String> ptags = new ArrayList<>();
                ArrayList<String> ltags = new ArrayList<>();

                if(!hasP && !hasL)
                    Toast.makeText(getApplicationContext(), "Sorry, at least one tag is required to search.", Toast.LENGTH_SHORT).show();
                if (hasP) {
                    personTags = personString.trim().toLowerCase().split(",");
                    for(String t: personTags) {
                        ptags.add(t.trim());
                    }
                }
                if (hasL) {
                    locationTags = locationString.trim().toLowerCase().split(",");
                    for(String t: locationTags) {
                        ltags.add(t.trim());
                    }
                }

                boolean includePhoto = true;
                search_photos = new ArrayList<>();
                for (Album a: albumsList) {
                    for (Photo p: a.getPhotosList()) {
                        includePhoto = true;
                        ArrayList<String> p_people = new ArrayList<>();
                        ArrayList<String> p_places = new ArrayList<>();
                        p.getPlaces();
                        for(String t: p.getPeople())
                            p_people.add(t.toLowerCase());
                        for (String t: p.getPlaces())
                            p_places.add(t.toLowerCase());
                        boolean tagFound = false;
                        if (ptags != null && ptags.size() > 0)
                        {
                            for (String p_person: p_people) {
                                for (String ptag: ptags) {
                                    if (p_person.contains(ptag))
                                    {
                                        includePhoto = includePhoto && true;
                                        tagFound = true;
                                        break;
                                    }
                                }
                                if(tagFound == true) break;
                            }
                            if (tagFound == false)
                                includePhoto = includePhoto && false;
                        }
                        tagFound = false;
                        if (ltags != null && ltags.size() > 0) {
                            for (String p_place: p_places) {
                                for(String ltag: ltags) {
                                    if (p_place.contains(ltag)) {
                                        includePhoto = includePhoto && true;
                                        tagFound = true;
                                        break;
                                    }
                                }
                                if(tagFound == true) break;
                            }
                            if (tagFound == false)
                                includePhoto = includePhoto && false;
                        }
                        if (includePhoto == true) {
                            search_photos.add(p);
                        }
                    }
                }
                if (search_photos != null && search_photos.size() > 0) {
                    Intent searchResults = new Intent(getApplicationContext(), SearchResultsActivity.class);
                    searchResults.putExtra("results", search_photos);
                    startActivity(searchResults);
                }
                else {
                    Toast.makeText(getApplicationContext(), "No Search Results, Try Again.", Toast.LENGTH_SHORT).show();
                }
                dialog.dismiss();
            }
        });

        builder.setNegativeButton("Cancel", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which)
            {
                dialog.dismiss();
            }
        }
        );

        return builder.create();
    }

    public static void m3 ()
    {   int i=1;
    float b= 2;
        //HelperMethodA();
    }
    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        // Here, thisActivity is the current activity

        if (ContextCompat.checkSelfPermission(this, Manifest.permission.READ_EXTERNAL_STORAGE) != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(this, new String[]{Manifest.permission.READ_EXTERNAL_STORAGE}, 1);
        }

        if (ContextCompat.checkSelfPermission(this, Manifest.permission.WRITE_EXTERNAL_STORAGE) != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(this, new String[]{Manifest.permission.WRITE_EXTERNAL_STORAGE}, 1);
        }


        if (ContextCompat.checkSelfPermission(this, Manifest.permission.CAMERA) != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(this, new String[]{Manifest.permission.CAMERA}, 1);
        }
        setContentView(R.layout.activity_main);
        albview = (ListView) findViewById(R.id.listView);


       try {
            File f = new File(getApplication().getFilesDir() + File.separator + Serial.ALBUM_FILE);
            if (f.exists()) {
                Log.e("File", "Read existing file.");
                read_albums();
            } else {
                Log.e("File", "Created new file.");
                File dir = getApplication().getFilesDir();
                if (dir.isDirectory()) {
                    for (File entry : dir.listFiles()) {
                        entry.delete();
                    }
                }
                ArrayList<Album> albs = new ArrayList<Album>();
                Album.setAlbumsAll(albs);
                write_albums();
            }
        } catch (Exception e) {

        }

        albumsList = Album.getAlbumsAll();
        albumNames = new ArrayList<>();

        for (Album a: Album.getAlbumsAll())
        {
            albumNames.add(a.getName());
        }

        albumAdapter = new ArrayAdapter<Album>(this, android.R.layout.simple_list_item_1, albumsList);
        albview.setAdapter(albumAdapter);
        albview.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> adapterView, View view, int position, long l) {
                albview.setSelection(position);
                Album.setCurrentAlbum(albumsList.get(position));
            }
        });

        final Button dBUTT = (Button) findViewById(R.id.dbutt);
        final Button cButt = (Button) findViewById(R.id.cbutt);
        final Button oButt = (Button) findViewById(R.id.obutt);
        final Button rButt = (Button) findViewById(R.id.rbutt);
        final Button sButt = (Button) findViewById(R.id.sbutt);

        View.OnClickListener handler = new View.OnClickListener(){

            public void onClick(View v) {

                if(v==dBUTT){
                    Log.i("content "," delete selected "  + albumsList.size());
                    Album currAlbum = Album.getCurrentAlbum();
                    if (currAlbum == null)
                        return;
                    Log.i("current album", currAlbum.getName());

                    albumAdapter.remove(currAlbum);

                    Album.setCurrentAlbum(null);

                    albumAdapter.notifyDataSetChanged();
                    try{
                        write_albums();
                    }
                    catch (Exception e)
                    {

                        Log.i("write album", "error message");
                    }
                }

                if(v==cButt){
                    Log.i("Content "," C selected "  + albumsList.size());
                    Intent createAlbum = new Intent(getApplicationContext(), CreateAlbumActivity.class);
                    startActivityForResult(createAlbum, 1);
                }

                if(v==oButt){
                    Log.i("Content "," O selected ");
                    if (Album.getCurrentAlbum() == null)
                        return;
                    Intent openAlbum = new Intent(getApplicationContext(), AlbumActivity.class);

                    startActivity(openAlbum);
                }

                if(v==rButt){
                    Log.i("Content "," R selected "  + albumsList.size());

                    if (Album.getCurrentAlbum() == null)
                        return;

                    Intent renameAB = new Intent(getApplicationContext(), CreateAlbumActivity.class);
                    startActivityForResult(renameAB, 2);
                }

                if (v==sButt) {
                    Log.i("Content ", " S selected ");

                    AlertDialog D = searchD();
                    D.show();
                }
            }
        };

        dBUTT.setOnClickListener(handler);
        cButt.setOnClickListener(handler);
        oButt.setOnClickListener(handler);
        rButt.setOnClickListener(handler);
        sButt.setOnClickListener(handler);




    }

    @Override
    protected void onActivityResult(int reqc1, int rc1, Intent dt) {
        super.onActivityResult(reqc1, rc1, dt);
        if(reqc1==1)
        {
            if (rc1 == 1)
                {
                String mm=dt.getStringExtra("NEWNAME");
                if(mm.isEmpty() || Album.nameOfIndex(mm)>=0)

                 {
                    AlertDialog.Builder b1 = new AlertDialog.Builder(this);
                    b1.setTitle("ERROR");

                    if(Album.nameOfIndex(mm)>=0){
                        b1.setMessage("Name is already there");
                        b1.setCancelable(true);
                        b1.setNeutralButton(android.R.string.ok,

                                new DialogInterface.OnClickListener()
                                {
                                    public void onClick(DialogInterface dialog, int id) {
                                        dialog.cancel();
                                    }
                                });

                        AlertDialog alert11 = b1.create();
                        alert11.show();
                        return;
                    }

                    if(mm.isEmpty()){
                        b1.setMessage("Album name can't be empty");

                        b1.setCancelable(true);

                        b1.setNeutralButton(android.R.string.ok,
                                new DialogInterface.OnClickListener()
                                    {
                                    public void onClick(DialogInterface dialog, int id)

                                        {
                                        dialog.cancel();
                                    }
                                });

                        AlertDialog alertA = b1.create();
                        alertA.show();
                        return;
                    }
                }
                else{
                    Album A1 = new Album(mm);
                    Album.setCurrentAlbum(A1);

                    albumAdapter.add(A1);
                    albumAdapter.notifyDataSetChanged();

                    try{
                        write_albums();
                    } catch (Exception e){
                        Log.i("write album", "error message");
                    }
                }
            }
        }
        if(reqc1==2)
        {
            if (rc1 == 1)
                {
                String nn=dt.getStringExtra("NEWNAME");
                //traversing through album
                Album a = Album.getCurrentAlbum();

                if((nn.isEmpty() || !nn.equalsIgnoreCase(a.getName())&&Album.nameOfIndex(nn)>=0))
                {
                    AlertDialog.Builder buildset = new AlertDialog.Builder(this);
                    buildset.setTitle("ERROR");

                    if((!nn.equalsIgnoreCase(a.getName())&&Album.nameOfIndex(nn)>=0)){
                        buildset.setMessage("Name is already there");
                        buildset.setCancelable(true);
                        buildset.setNeutralButton(android.R.string.ok,

                                new DialogInterface.OnClickListener()

                                {
                                    public void onClick(DialogInterface dialog, int id)

                                    {
                                        dialog.cancel();
                                    }
                                });


                        AlertDialog alertA = buildset.create();
                        alertA.show();
                        return;
                    }

                    if(nn.isEmpty())
                        {
                        buildset.setMessage("Album name cannot be empty");

                        buildset.setCancelable(true);

                        buildset.setNeutralButton(android.R.string.ok,
                                new DialogInterface.OnClickListener()
                                {
                                    public void onClick(DialogInterface dialog, int id) {
                                        dialog.cancel();
                                    }
                                });

                        AlertDialog alert11 = buildset.create();
                        alert11.show();
                        return;
                    }

                    return;
                }
                else
                    {
                    a.setName(nn);

                    albumAdapter.notifyDataSetChanged();
                    try{
                        write_albums();
                    } catch (Exception e){
                        Log.i("write album", "error message");
                    }
                }


            }
        }
    }

    public void write_albums() throws IOException {

        Serial.writeContextToFile(getApplication());
    }

    public void read_albums() throws IOException, ClassNotFoundException{

        Serial.readContextFromFile(getApplication());
    }
}
