package com.example.user.photos;

import java.io.Serializable;

public class Tag implements Serializable{
    public static final long serialVersionUID= 1L;
    private String name;
    private String value;

    public Tag(String n, String v) {
        this.name = n;
        this.value = v;
    }

    public String getName()
    {
        return this.name;
    }


    @Override
    public String toString()
    {
        return name + ":" + value;
    }


    @Override
    public boolean equals(Object o)
    {
        if(!(o instanceof Tag)){
            return false;
        }
        Tag t1 = (Tag)o;

        if(this.name.equals(t1.name)&&(this.value.equalsIgnoreCase(t1.value))){
            return true;
        }
        else{
            return false;
        }
    }
}