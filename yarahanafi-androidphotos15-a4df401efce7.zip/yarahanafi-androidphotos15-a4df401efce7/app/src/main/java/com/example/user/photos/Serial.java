package com.example.user.photos;

import android.Manifest;
import android.content.Context;
import android.content.pm.PackageManager;
import android.util.Log;

import androidx.core.content.ContextCompat;

import java.io.EOFException;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.Serializable;
import java.util.ArrayList;



public class Serial implements Serializable {
    public static final long serialversionid = 1L;

    protected static ArrayList<Album> albums;
    public static final String ALBUM_FILE = "albums.dat";

    public static void writeContextToFile(Context context) throws IOException {
        /*FileOutputStream fos = context.openFileOutput("user.dat", Context.MODE_PRIVATE);
        ObjectOutputStream oos = new ObjectOutputStream(fos);
        for (Album album: Album.getAlbumsAll()) {
            oos.writeObject(album.getBytes());
        }
        oos.close();*/
        ObjectOutputStream os;
        try {
            os = new ObjectOutputStream(new FileOutputStream(context.getFilesDir() + File.separator + Serial.ALBUM_FILE));
            //os = new ObjectOutputStream(context.openFileOutput(ALBUM_FILE, Context.MODE_WORLD_WRITEABLE));
            os.writeObject(Album.getAlbumsAll());
            os.close();
            Log.i("File write", "success");
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }


    public static void readContextFromFile(Context context) throws IOException, ClassNotFoundException {
        /*FileInputStream fis = context.openFileInput("user.dat");
        ObjectInputStream ois = new ObjectInputStream(fis);
        Album u;
        try {
            while((u = (Album) ois.readObject())!=null) {
                Album.addAlbum(u);
            }
        } catch(EOFException e) {}
        ois.close();*/

            ObjectInputStream ois;
            try {
                ois = new ObjectInputStream(new FileInputStream(context.getFilesDir() + File.separator + Serial.ALBUM_FILE));
                albums = (ArrayList<Album>) ois.readObject();
                ois.close();
                Log.i("File read", "success");
                Album.setAlbumsAll(albums);
            } catch (Exception e) {
                e.printStackTrace();
            }
    }
}
