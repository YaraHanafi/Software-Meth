package com.example.user.photos;

import android.app.Activity;
import android.content.Intent;

import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

public class CreateAlbumActivity extends Activity {
    Button mButton;
    EditText mEdit;
    String newname;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_create_album);

        mButton = (Button)findViewById(R.id.submit_button);
        mEdit   = (EditText)findViewById(R.id.new_name);

        mButton.setOnClickListener(
                new View.OnClickListener()
                {
                    public void onClick(View view)
                    {
                        newname =  mEdit.getText().toString();
                        Intent r1 = getIntent();
                        r1.putExtra("NEWNAME", newname);
                        setResult(1, r1);
                        finish();
                    }
                });


    }
}
