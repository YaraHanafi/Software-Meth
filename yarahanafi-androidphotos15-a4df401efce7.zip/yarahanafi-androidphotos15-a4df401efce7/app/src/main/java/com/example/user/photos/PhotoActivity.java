package com.example.user.photos;

import android.content.DialogInterface;
import android.graphics.drawable.Drawable;
import android.os.Bundle;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;

import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.net.URL;
import java.util.ArrayList;

public class PhotoActivity extends AppCompatActivity {

    private Photo currPhoto;
    private ArrayList<Photo> photos = Album.getCurrentAlbum().getPhotosList();

    private ImageView imageView;
    private TextView pCaption, pTags;
    private EditText personBox, locationBox;
    private static final String storeFile = "album.bin";

    protected void refresh_info() throws FileNotFoundException {
        currPhoto = Photo.getCurrentPhoto();
        pCaption.setText(currPhoto.get_Name());
        pTags.setText("People:" + currPhoto.printPeople()+ "\n" + "Places:" + currPhoto.printPlaces());

        imageView = (ImageView)findViewById(R.id.photo_imageview);

        Thread thread = new Thread(new Runnable() {

            @Override
            public void run() {
                try  {
                    InputStream inputStream = new URL (currPhoto.get_source()).openStream();
                    //Bitmap bmp = BitmapFactory.decodeStream(inputStream);
                    //InputStream inputStream = (InputStream) getContentResolver().openInputStream(Uri.parse(currPhoto.get_source()));
                    //InputStream inputStream = currPhoto.get_in();
                    Drawable drawable = Drawable.createFromStream(inputStream, null);
                    imageView.setImageDrawable(drawable);
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
        });

        thread.start();


    }



    private AlertDialog AddTagsDialog() {
        LayoutInflater inflater = (LayoutInflater) getSystemService(LAYOUT_INFLATER_SERVICE);
        View layout = inflater.inflate(R.layout.edit_tags, null, false);

        personBox = (EditText) layout.findViewById(R.id.edit_person_field);
        locationBox = (EditText) layout.findViewById(R.id.edit_location_field);

        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setView(layout);
        builder.setPositiveButton("Confirm", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                String personString = personBox.getText().toString();
                String locationString = locationBox.getText().toString();
                boolean hasP = (personString != null && !personString.trim().equals(""));
                boolean hasL = (locationString != null && !locationString.trim().equals(""));
                if (hasP) {
                    currPhoto.addPeople(personString);
                    Album.addPeopleTag(personString);
                }
                if (hasL) {
                    currPhoto.addPlaces(locationString);
                    Album.addPlaceTag(locationString);
                }
                try {
                    refresh_info();
                } catch (FileNotFoundException e) {
                    e.printStackTrace();
                }
                try{
                    write_albums();
                } catch (Exception e){
                    Log.i("write albums","error");
                }
                dialog.dismiss();
            }
        });
        builder.setNegativeButton("Cancel", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                dialog.dismiss();
            }
        });
        return builder.create();
    }

    private AlertDialog TagdeleteDialog() {
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setTitle("Pick Tag to delete");
        final ArrayList<String> tags1 = currPhoto.getPeople();
        final ArrayList<String> tags2 = currPhoto.getPlaces();
        final ArrayList<String> alltags = new ArrayList<String>();

        for (int j=0; j<tags1.size();j++){
            alltags.add(tags1.get(j));
        }
        for (int l=0; l<tags2.size();l++){
            alltags.add(tags2.get(l));
        }

        String[] tagNames = new String[tags1.size() + tags2.size()];
        int i = 0;

        for (String a: tags1) {
            tagNames[i] = a;
            i++;
        }
        for (String a: tags2) {
            tagNames[i] = a;
            i++;
        }
        builder.setItems(tagNames, new DialogInterface.OnClickListener() {

            public void onClick(DialogInterface dialog, int which) {
                Photo photo = Photo.getCurrentPhoto();
                String selectedTag = alltags.get(which);
                alltags.remove(which);
                if (tags1.remove(selectedTag) == false) {
                    tags2.remove(selectedTag);
                    Album.removePlaceTag(selectedTag);
                } else {
                    tags1.remove(selectedTag);
                    Album.removePeopleTag(selectedTag);
                }

                dialog.dismiss();
                try {
                    refresh_info();
                } catch (FileNotFoundException e) {
                    e.printStackTrace();
                }
                try {
                    write_albums();
                } catch (Exception e) {
                    Log.i("write albums", "error");
                }
            }
        });
        builder.setNegativeButton("Cancel", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                dialog.dismiss();
            }
        });
        return builder.create();

    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_photo);

        imageView = (ImageView) findViewById(R.id.photo_imageview);
        pCaption = (TextView) findViewById(R.id.photo_caption);
        pTags = (TextView) findViewById(R.id.photo_tags);

        try {
            refresh_info();
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        }

        final Button leftBtn = (Button) findViewById(R.id.left_button);
        final Button addBtn = (Button) findViewById(R.id.add_button);
        final Button rightBtn = (Button) findViewById(R.id.right_button);
        final Button deleteBtn= (Button) findViewById(R.id.dbutt);

        View.OnClickListener handler = new View.OnClickListener(){

            public void onClick(View v) {

                if(v==leftBtn){
                    int curr_idx = photos.indexOf(currPhoto);
                    int len = photos.size();
                    int prev_idx = (len + curr_idx - 1) % len;
                    Photo prev_photo = photos.get(prev_idx);
                    Photo.setCurrentPhoto(prev_photo);
                    try {
                        refresh_info();
                    } catch (FileNotFoundException e) {
                        e.printStackTrace();
                    }
                }

                if(v==rightBtn){
                    int curr_idx = photos.indexOf(currPhoto);
                    int len = photos.size();
                    int next_idx = (curr_idx + 1) % len;
                    Photo prev_photo = photos.get(next_idx);
                    Photo.setCurrentPhoto(prev_photo);
                    try {
                        refresh_info();
                    } catch (FileNotFoundException e) {
                        e.printStackTrace();
                    }
                }
                if(v == addBtn){
                    Log.i("Content ", " ADD pressed ");
                    AlertDialog dialog = AddTagsDialog();
                    dialog.show();
                }
                if(v == deleteBtn){
                    Log.i("Content ", " DELETE pressed ");
                    AlertDialog dialog = TagdeleteDialog();
                    dialog.show();
                }
            }
        };

        leftBtn.setOnClickListener(handler);
        rightBtn.setOnClickListener(handler);
        addBtn.setOnClickListener(handler);
        deleteBtn.setOnClickListener(handler);

    }
    public void write_albums() throws IOException {
        /*File outfile = new File(getFilesDir(),storeFile);
        ObjectOutputStream os = new ObjectOutputStream(new FileOutputStream(outfile));
        for (Album u : Album.getAlbumsAll()) {
            os.writeObject(u);
        }
        os.flush();
        os.close();*/
        Serial.writeContextToFile(getApplication());
    }

}

