package com.example.user.photos;

import java.io.*;
import java.util.ArrayList;
import java.lang.Comparable;

public class Photo implements Comparable<Photo>,Serializable {

    public static final long seriaID = 2L;
    private static Photo CURRENTPH;
    private String name2;
    private String s2;
    private ArrayList<String> people;
    private ArrayList<String> places;
    private InputStream in;


    public Photo(String s)

        {
        this.s2 = s;

        this.people = new ArrayList<String>();
        this.places = new ArrayList<String>();
    }

    public InputStream  get_in()
    {
        return this.in;
    }

    public void set_in(InputStream c) { this.in = c; }

    public String get_Name()
    {
        return this.name2;
    }

    public void set_Name(String c) { this.name2 = c; }

    public String get_source()
    {
        return this.s2;
    }

    public static Photo getCurrentPhoto()
    {
        return CURRENTPH;
    }

    public static void setCurrentPhoto(Photo p)
    {
        CURRENTPH = p;
    }

    public String printPeople()
    {
        String retStr = "";
        for (String s : this.people){
            retStr += "" + s +",";
        }
        return retStr;
    }

    public String printPlaces()
    {
        String retStr = "";
        for (String s : this.places){
            retStr += "" + s +",";
        }
        return retStr;
    }

    public ArrayList<String> getPeople()
    {
        return this.people;
    }

    public ArrayList<String> getPlaces()
    {
        return this.places;
    }

    public void addPeople(String new_p) {
        this.people.add(new_p);
    }

    public void addPlaces(String new_p)
    {
        this.places.add(new_p);
    }

    @Override
    public int compareTo(Photo p) {
        return this.s2.compareTo(p.get_source());
    }

    @Override
    public String toString()
    {
        return "Photo [caption = " + name2 + ", source = " + s2 + ", people = " + people + ", places = " + places + "]";
    }
}