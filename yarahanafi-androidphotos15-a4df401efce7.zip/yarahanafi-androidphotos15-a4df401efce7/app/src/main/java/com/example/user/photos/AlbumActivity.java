package com.example.user.photos;

import android.app.ListActivity;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import androidx.appcompat.app.AlertDialog;

import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.Toast;

import java.io.IOException;
import java.util.ArrayList;

public class AlbumActivity extends ListActivity {
    private PhotoAdapter adapter;

    private ListView myListView;
    private static final String storeFile = "album.bin";

    ArrayList<Photo> photosList = Album.getCurrentAlbum().getPhotosList();

    private static final int SELECT_PICTURE = 1;

    private String selectedImagePath;

    /*private void AddPhoto() {
        Intent intent = new Intent();
        intent.setType("image/*");
        intent.setAction(Intent.ACTION_GET_CONTENT);
        startActivityForResult(Intent.createChooser(intent, "Select Picture"), SELECT_PICTURE);
    }

    public void onActivityResult(int requestCode, int resultCode, Intent data) {

        if (resultCode == RESULT_OK) {
            if (requestCode == SELECT_PICTURE) {
                Uri selectedImageUri = data.getData();
                selectedImagePath = selectedImageUri.toString();
                Photo photo = new Photo(selectedImagePath);
                String name = getFileName(selectedImageUri);
                for(int i=0; i<photosList.size(); i++){
                    if(photosList.get(i).get_Name().equals(name)){
                        Toast.makeText(getApplicationContext(), "Photo already exists in the album", Toast.LENGTH_SHORT).show();
                        return;
                    }
                }
                photo.set_Name(name);
                photosList.add(photo);
                Photo.set_current_photo(photo);
                myListView.setSelection(photosList.indexOf(photo));
            }

        }
    }

    public String getFileName(Uri uri) {
        String ans = null;
        if (uri.getScheme().equals("content")) {
            Cursor cursor = getContentResolver().query(uri, null, null, null, null);
            try {
                if (cursor != null && cursor.moveToFirst()) {
                    ans = cursor.getString(cursor.getColumnIndex(OpenableColumns.DISPLAY_NAME));
                }
            } finally {
                cursor.close();
            }
        }
        if (ans == null) {
            ans = uri.getPath();
            int cut = ans.lastIndexOf('/');
            if (cut != -1) {
                ans = ans.substring(cut + 1);
            }
        }
        return ans;
    }*/

    private AlertDialog newPhoto() {
        LayoutInflater inflater = (LayoutInflater) getSystemService(LAYOUT_INFLATER_SERVICE);
        View layout = inflater.inflate(R.layout.dialog_layout, null, false);
        final EditText urlBox = (EditText) layout.findViewById(R.id.URL);

        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setView(layout);
        builder.setPositiveButton("Save", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                String url = urlBox.getText().toString();
                if(url == null || url.trim().equals(""))
                    Toast.makeText(getApplicationContext(), "Please insert a URL", Toast.LENGTH_SHORT).show();
                else {
                    Photo photo = new Photo(url);
                    String name = getFileName(url);
                    photo.set_Name(name);
                    for(int i=0; i<photosList.size(); i++){
                        if(photosList.get(i).get_Name().equals(name)){
                            Toast.makeText(getApplicationContext(), "Photo already exists in the album", Toast.LENGTH_SHORT).show();
                            return;
                        }
                    }
                    photosList.add(photo);
                    Photo.setCurrentPhoto(photo);
                    myListView.setSelection(photosList.indexOf(photo));
                    dialog.dismiss();
                    try{
                        write_albums();
                    } catch (Exception e){
                        Log.i("write albums", "error");
                    }
                }
            }
        });
        builder.setNegativeButton("Cancel", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                dialog.dismiss();
            }
        });
        return builder.create();
    }

    public String getFileName(String url) {
        String ans = null;
       ans = url;
        int cut = ans.lastIndexOf('/');
        if (cut != -1) {
            ans = ans.substring(cut + 1);
        }

        return ans;
    }


    private AlertDialog albumMoveDialog() {
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setTitle("Pick Album");
        final ArrayList<Album> albumsList = Album.getAlbumsAll();
        String[] albumNames = new String[albumsList.size()];
        final Album currAlbum = Album.getCurrentAlbum();

        final int idx = albumsList.indexOf(currAlbum);
        int i = 0;
        for (Album a: albumsList) {
            albumNames[i] = a.getName();
            i++;
        }
        builder.setItems(albumNames, new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialog, int which) {
                        Photo photo = Photo.getCurrentPhoto();
                        Album selectedAlbum = albumsList.get(which);
                        if (idx == which)
                            Toast.makeText(getApplicationContext(), "Cannot move to same album, try another album", Toast.LENGTH_SHORT).show();
                        else {
                            selectedAlbum.addPhoto(photo);
                            currAlbum.removePhoto(photo);
                            adapter.remove(photo);
                            photosList.remove(photo);
                            Photo.setCurrentPhoto(null);
                            adapter.notifyDataSetChanged();
                            dialog.dismiss();
                            try{
                                write_albums();
                            } catch (Exception e){
                                Log.i("write albums", "error");
                            }
                        }
                    }
                });
        builder.setNegativeButton("Cancel", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                dialog.dismiss();
            }
        });
        return builder.create();
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        /*if (ContextCompat.checkSelfPermission(this, Manifest.permission.READ_EXTERNAL_STORAGE) != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(this, new String[]{Manifest.permission.READ_EXTERNAL_STORAGE}, 1);
        }

        if (ContextCompat.checkSelfPermission(this, Manifest.permission.WRITE_EXTERNAL_STORAGE) != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(this, new String[]{Manifest.permission.WRITE_EXTERNAL_STORAGE}, 1);
        }

        if (ContextCompat.checkSelfPermission(this, Manifest.permission.CAMERA) != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(this, new String[]{Manifest.permission.CAMERA}, 1);
        }*/
        setContentView(R.layout.activity_album);

        myListView = getListView();
        adapter = new PhotoAdapter(getApplicationContext(), R.layout.photo_cell, photosList);

        myListView.setAdapter(adapter);

        myListView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> adapterView, View view, int position, long id) {
                myListView.setSelection(position);
                Photo.setCurrentPhoto(photosList.get(position));
            }
        });

        final Button deleteBtn = (Button) findViewById(R.id.dbutt);
        final Button uploadBtn = (Button) findViewById(R.id.upload_button);
        final Button openBtn = (Button) findViewById(R.id.obutt);
        final Button moveBtn = (Button) findViewById(R.id.move_button);

        View.OnClickListener handler = new View.OnClickListener(){

            public void onClick(View v) {

                if(v==deleteBtn){
                    Log.i("AlbumActivity "," DELETE pressed ");

                    Photo currPhoto = Photo.getCurrentPhoto();
                    if (currPhoto == null)
                        return;

                    Log.i("current album", currPhoto.get_Name());

                    Album.getCurrentAlbum().removePhoto(currPhoto);
                    adapter.remove(currPhoto);
                    photosList.remove(currPhoto);
                    Photo.setCurrentPhoto(null);
                    adapter.notifyDataSetChanged();

                    try{
                        write_albums();
                    } catch (Exception e){
                        Log.i("write albums", "error");
                    }
                }

                if(v==uploadBtn){
                    Log.i("AlbumActivity"," CREATE pressed "  + photosList.size());
                    int h = Album.getCurrentAlbum().getPhotosList().size();
                    AlertDialog dialog = newPhoto();
                    dialog.show();
                    //AddPhoto();
                    try{
                        write_albums();
                    } catch (Exception e){
                        Log.i("write albums", "error");
                    }
                }

                if(v==openBtn){
                    Log.i("AlbumActivity"," OPEN pressed ");
                    if (Photo.getCurrentPhoto() == null)
                        return;
                    Intent intent = new Intent(getApplicationContext(), PhotoActivity.class);
                    startActivity(intent);
                }

                if(v==moveBtn){
                    Log.i("AlbumActivity"," MOVE pressed "  + photosList.size());
                    if (Photo.getCurrentPhoto() == null)
                        return;
                    AlertDialog dialog = albumMoveDialog();
                    dialog.show();
                }
            }
        };

        deleteBtn.setOnClickListener(handler);
        uploadBtn.setOnClickListener(handler);
        openBtn.setOnClickListener(handler);
        moveBtn.setOnClickListener(handler);
    }

    public void write_albums() throws IOException {
        /*ObjectOutputStream os = new ObjectOutputStream(new FileOutputStream(Album.storeDir + File.separator + storeFile));
        for (Album album: Album.getAlbumsAll()) {
            os.writeObject(album);
        }
        os.close();*/
        Serial.writeContextToFile(getApplication());
    }


}
