package com.example.user.photos;

import java.io.*;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Locale;

public class Album implements Serializable {

    public static final long serialversionid = 1L;

    public static final String storeDir = "dat";
    public static final String storeFile = "Album.dat";

    private int drawable = 0;


    private static ArrayList<Album> albumsAll = new ArrayList<Album>();
    private static ArrayList<String> peopleTagsAll = new ArrayList<String>();
    private static ArrayList<String> placesTagsAll = new ArrayList<String>();

    private ArrayList<Photo> photosList = new ArrayList<Photo>();

    private String name;
    private static Album currentAlbum;

    public void getDrawable(int d) {
        this.drawable = d;
        updateInfo();
    }

    public Album(String name) {
        this.name = name;

    }

    public static ArrayList<String> getPeopleTagsAll()
    {
        return peopleTagsAll;
    }

    public static ArrayList<String> getPlaceTagsAll()
    {
        return placesTagsAll;
    }

    public String getName()
    {
        return this.name;
    }


    public void setName(String name)
    {
        this.name = name;
    }

    public void setDrawableHelperMethodB (int a)
    { this.drawable= a;
    getDrawable(drawable);
    }

    public ArrayList<Photo> getPhotosList()
    {
        return this.photosList;
    }

    public void updateInfo() {
        if(this.photosList.isEmpty())
        {
            return;
        }

        else
        {
            Collections.sort(this.photosList);
        }
    }
    public void removePhoto(Photo singlephoto) {
        this.photosList.remove(singlephoto);
        updateInfo();
    }

    public void addPhoto(Photo p) {
        this.photosList.add(p);
        updateInfo();
    }

    public static Album getCurrentAlbum()
    {
        return currentAlbum;
    }

    public static void setCurrentAlbum(Album curr)
    {
        currentAlbum = curr;
    }


    @Override
    public boolean equals(Object o) {
        if (!(o instanceof Album))
        {
            return false;
        }

        Album c = (Album) o;

        if (!(this.name.equalsIgnoreCase(c.getName()))) {
            return false;
        }
        return true;
    }


    @Override
    public String toString()

    {
        return this.name;
    }

    public static ArrayList<Album> getAlbumsAll()
    {
        return albumsAll;
    }

    public static void setAlbumsAll(ArrayList<Album> k1)
    {
        albumsAll=k1;
    }

//
    public static long traverseAlbum (long k1)
    {
        return k1;

    }
    public static void addAlbum(Album k1)
    {
        albumsAll.add(k1);
    }




    public static void addPeopleTag(String a)
    {
        String f= a.toLowerCase();
    if (!peopleTagsAll.contains(f))
        peopleTagsAll.add(f);
    }

    public static void addPlaceTag(String a)
    {
        String f= a.toLowerCase();
        if (!placesTagsAll.contains(f))
            placesTagsAll.add(f);
    }


    public static void removePeopleTag(String a)
    {
        String f= a.toLowerCase();
        if (peopleTagsAll.contains(f))
            peopleTagsAll.remove(f);
    }

    public static void removePlaceTag(String a)
    {
        String f= a.toLowerCase();
        if (placesTagsAll.contains(f))
            placesTagsAll.remove(f);
    }

    public static int nameOfIndex (String n)
    {
        int i = -1;


        for(Album album : Album.getAlbumsAll())

            {

            if (album.getName().equalsIgnoreCase(n)) {
                i = Album.getAlbumsAll().indexOf(album);
                break;
            }
        }
        return i;
    }


}