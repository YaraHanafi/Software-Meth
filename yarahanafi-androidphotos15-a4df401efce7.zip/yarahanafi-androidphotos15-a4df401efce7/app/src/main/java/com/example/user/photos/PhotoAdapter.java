package com.example.user.photos;

import static android.content.Intent.FLAG_ACTIVITY_NEW_TASK;

import android.Manifest;
import android.app.Activity;
import android.app.ListActivity;
import android.content.ContentResolver;
import android.content.Context;
import androidx.annotation.Nullable;
import androidx.annotation.RequiresApi;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.drawable.Drawable;
import android.net.Uri;
import android.os.AsyncTask;
import android.os.Build;
import android.os.StrictMode;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.google.android.gms.common.util.IOUtils;
import com.squareup.picasso.Picasso;

import java.io.*;
import java.net.URL;
import java.net.URLDecoder;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.Base64;

public class PhotoAdapter extends ArrayAdapter<Photo>{


    Context context;
    ArrayList<Photo> photosList;

    public PhotoAdapter(Context context, int resource, ArrayList<Photo> objects) {
        super(context, resource, objects);

        this.context = context;
        this.photosList = objects;
    }

    @Override
    public int getCount() {
        if(photosList != null)
            return photosList.size();
        return 0;
    }

    @Nullable
    @Override
    public Photo getItem(int position) {
        if(photosList != null)
            return photosList.get(position);
        return null;
    }

    @Override
    public long getItemId(int position) {
        if(photosList != null)
            return photosList.get(position).hashCode();
        return 0;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {

        Holder holder;

        if (convertView == null){

            holder = new Holder();

            LayoutInflater inflater = (LayoutInflater)context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);

            convertView = inflater.inflate(R.layout.photo_cell, null);

            holder.txtName = (TextView)convertView.findViewById(R.id.photo_cell_caption);
            holder.imageView = (ImageView)convertView.findViewById(R.id.photo_cell_imageview);

            convertView.setTag(holder);

        }else {

            holder = (Holder) convertView.getTag();

        }
        Photo photo = getItem(position);

        holder.txtName.setText(photo.get_Name());
        LinearLayout.LayoutParams layoutParams = new LinearLayout.LayoutParams(300, 300);
        holder.imageView.setLayoutParams(layoutParams);


        /*Intent iin= new Intent();
        iin.setType("image/*");
        iin.setAction(Intent.ACTION_OPEN_DOCUMENT);
        iin.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
        context.startActivity(iin);*/


            //context.grantUriPermission(context.getPackageName(), Uri.parse(photo.get_source()), Intent.FLAG_GRANT_READ_URI_PERMISSION| Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION);
            //context.getContentResolver().takePersistableUriPermission(Uri.parse(photo.get_source()), Intent.FLAG_GRANT_WRITE_URI_PERMISSION );
        //context.grantUriPermission(context.getPackageName(), Uri.parse(photo.get_source()), Intent.FLAG_GRANT_READ_URI_PERMISSION| Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION);
        //context.getContentResolver().takePersistableUriPermission(Uri.parse(photo.get_source()), Intent.FLAG_GRANT_WRITE_URI_PERMISSION );







                //holder.imageView.setImageBitmap(bmp);

        Thread thread = new Thread(new Runnable() {

            @Override
            public void run() {
                try  {
                    InputStream inputStream = new URL (photo.get_source()).openStream();
                    //Bitmap bmp = BitmapFactory.decodeStream(inputStream);
                    //InputStream inputStream = (InputStream) context.getContentResolver().openInputStream(Uri.parse(photo.get_source()));
                    //InputStream inputStream = photo.get_in();
                    Drawable drawable = Drawable.createFromStream(inputStream, null);
                    holder.imageView.setImageDrawable(drawable);
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
        });

        thread.start();



        /*Picasso.with(context)
                .load(photo.get_source())
//                .fit().into(holder.imageView);
                .resize(300,300).into(holder.imageView);*/

        return convertView;

    }


    private class Holder {

        TextView txtName;
        ImageView imageView;

    }
}
